<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN"> <!--   -*- C++ -*-  -->

<?php  // Datei general/select.php

include("mylibraryconnect.inc.php");
$connID = connect_to_mylibrary();

// function show_table: defined in mylibraryconnect.inc.php

?>

<html><head>
<meta http-equiv="Content-Type" 
      content="text/html; charset=iso-8859-1" />
<title>PHP Programming, SELECT sample</title>
</head><body>

<?php 

  // process query
  $result = mysql_query("SELECT * FROM titles LIMIT 100");
 
  // show informations about result
  $rows = mysql_num_rows($result);
  $cols = mysql_num_fields($result);
  echo "<p>\$result = $result\n",
    "<br />mysql_num_rows(\$result) = $rows\n",
    "<br />mysql_num_cols(\$result) = $cols</p>\n";

  // show table
  echo "<p>\n";
  show_table($result);
  echo "</p>\n";
?>

<?php 
  show_copyright(); 
?>
</body></html>
