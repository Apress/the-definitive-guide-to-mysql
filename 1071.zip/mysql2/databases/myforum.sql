-- MySQL dump 9.07
--
-- Host: localhost    Database: myforum
---------------------------------------------------------
-- Server version	4.0.12-nt-log

--
-- Table structure for table 'forums'
--

CREATE TABLE forums (
  forumID int(11) NOT NULL auto_increment,
  forumName varchar(80) NOT NULL default '',
  language enum('deutsch','english') NOT NULL default 'english',
  timest timestamp(14) NOT NULL,
  PRIMARY KEY  (forumID)
) TYPE=MyISAM;

--
-- Dumping data for table 'forums'
--

INSERT INTO forums VALUES (2,'testforum','deutsch',20010116160339);
INSERT INTO forums VALUES (1,'testforum','english',20010116160339);

--
-- Table structure for table 'messages'
--

CREATE TABLE messages (
  msgID int(11) NOT NULL auto_increment,
  userID int(11) NOT NULL default '0',
  forumID int(11) NOT NULL default '0',
  parentID int(11) NOT NULL default '0',
  rootID int(11) NOT NULL default '0',
  subject varchar(80) NOT NULL default '',
  msgText text NOT NULL,
  level int(11) NOT NULL default '0',
  timest timestamp(14) NOT NULL,
  orderstr varchar(128) binary NOT NULL default '',
  PRIMARY KEY  (msgID),
  KEY rootID (rootID),
  KEY forumID (forumID),
  KEY orderstr (orderstr)
) TYPE=MyISAM;

--
-- Dumping data for table 'messages'
--

INSERT INTO messages VALUES (526,1,1,224,222,'Re: Re: message 4','bla bla\n\n-------------\n\nOriginal message:\n\nSubject: Re: message 4\nAuthor: kofler\nDate: 2001/1/5 16:25\n\nreply by kofler\n\n-------------\n\nOriginal message:\n\nSubject: message 4\nAuthor: testaccount\nDate: 2001/1/5 16:24\n\nsome text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text',2,20010219202916,':U�2:U�f:[�');
INSERT INTO messages VALUES (527,1,1,0,0,'message 6','bla bla',0,20010219202916,':[;�');
INSERT INTO messages VALUES (216,1,2,0,0,'testnachricht','testnachricht testnachricht testnachricht testnachricht ',0,20010105160808,':U�X');
INSERT INTO messages VALUES (217,1,2,216,216,'Re: testnachricht','Antwort auf testnachricht \n\nbla bla bla',1,20010105160830,':U�X:U�n');
INSERT INTO messages VALUES (219,2,1,0,0,'first message','message text message text message text message text  message text message text',0,20010219202916,':U�G');
INSERT INTO messages VALUES (220,2,1,0,0,'second message','message text message text message text message text message text message text message text message text message text message text message text message text message text',0,20010219202916,':U�f');
INSERT INTO messages VALUES (221,1,1,0,0,'third message','some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text',0,20010219202916,':U��');
INSERT INTO messages VALUES (222,8,1,0,0,'message 4','some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text',0,20010219202916,':U�2');
INSERT INTO messages VALUES (223,2,1,0,0,'message 5','some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text',0,20010219202916,':U�@');
INSERT INTO messages VALUES (224,2,1,222,222,'Re: message 4','reply by kofler\n\n-------------\n\nOriginal message:\n\nSubject: message 4\nAuthor: testaccount\nDate: 2001/1/5 16:24\n\nsome text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text some text',1,20010219202916,':U�2:U�f');
INSERT INTO messages VALUES (225,8,1,224,222,'Re: Re: message 4','this is nonsense!\n\n> reply by kofler',2,20010219202916,':U�2:U�f:U�');
INSERT INTO messages VALUES (528,1,1,0,0,'message 7 with a pretty long subject line','test',0,20030125155337,'>2��');

--
-- Table structure for table 'users'
--

CREATE TABLE users (
  userID int(11) NOT NULL auto_increment,
  username varchar(30) NOT NULL default '',
  email varchar(120) NOT NULL default '',
  password varchar(30) NOT NULL default '',
  timest timestamp(14) NOT NULL,
  PRIMARY KEY  (userID),
  KEY username (username)
) TYPE=MyISAM;

--
-- Dumping data for table 'users'
--

INSERT INTO users VALUES (1,'test','test@test.test','428567f408994404',20010116160417);
INSERT INTO users VALUES (2,'testuser','dontspamme@no.spam','66f6a37d50e41886',20010116160417);
INSERT INTO users VALUES (3,'anonymous','none','*',20010116160417);
INSERT INTO users VALUES (8,'testaccount','testaccount@dummy.com','4f44e7f74ec2d540',20030318174700);

