<?php  // file mylibrary/simpleinput.php     -*- C++ -*- 

// include some standard functions
include("mylibraryconnect.inc.php");

$formSubmit  = array_item($_POST, 'formSubmit');
$formTitle   = array_item($_POST, 'formTitle');
$formAuthors = array_item($_POST, 'formAuthors');

// connect to database
$connID = connect_to_mylibrary();

// start of html document if no connection error has happened 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html><head>
  <meta http-equiv="Content-Type" 
        content="text/html; charset=iso-8859-1" />
  <title>PHP Programming: Input a new title (mylibrary database)</title>
</head><body>
<h2>Input a new title for the mylibrary database</h2>

<?php

if($formSubmit) {
  // validate input

  // if data is missing: show error message and form again
  if(empty($formTitle) or empty($formAuthors)) {
    echo "<p>Please specify title and at least one author.</p>\n";

    // remove magic quotes
    if(get_magic_quotes_gpc()) {
      $formTitle = stripslashes($formTitle);
      $formAuthors = stripslashes($formAuthors);
    }

  }
  // else save data, then show cleared form for next input
  else {
    // loop through all authors
    $authCount=0;
    $authorsArray = explode(";", $formAuthors);
    while($i = each($authorsArray)) {
      $author = trim($i[1]);
      if($author) {
        // test whether author is already known
        $result = 
          mysql_query("SELECT authID FROM authors " .
                      "WHERE authName = '$author'");
        if(mysql_num_rows($result)) 
          $authIDs[$authCount++] = mysql_result($result, 0, 0);
        // if unknown, insert
        else {
          mysql_query("INSERT INTO authors (authName) " .
                      "VALUES('$author')");
          $authIDs[$authCount++] = mysql_insert_id();
        }
      }
    } // end loop authors
      
    // save title
    mysql_query("INSERT INTO titles (title) VALUES ('" .
                trim($formTitle) . "')");
    $titleID=mysql_insert_id();

    // save rel_title_author
    $sql = "INSERT INTO rel_title_author " .
      "(titleID, authID, authNr) VALUES ";
    for($i=0; $i<$authCount; $i++) {
      if($i!=0) $sql .= ",";
      $sql .= "($titleID, $authIDs[$i], $i)";
    }
    mysql_query($sql);
      
    // give minimal feedback
    echo "<p>Your last input has been saved and can be seen ",
      build_href("find.php", 
                 "sqlType=title&search=" . 
                 urlencode(stripslashes(trim($formTitle))), 
                 "here"), 
      ". ",
      "<br />You may now continue with the next title.</p>\n";

    // clear form for next input
    $formTitle = $formAuthors = "";
  } // end save block
}


?>

<form method="post" action="simpleinput.php">
<p>Title:
  <br />
  <input name="formTitle" size="60" maxlength="80"
         value="<?php echo htmlspecialchars($formTitle); ?>" /></p>
  <p>Authors: 
  <br /><input name="formAuthors" size="60" maxlength="100"
             value="<?php echo htmlspecialchars($formAuthors); ?>" />
  <br />(Last name first! If you want to specify more than one 
         author, use ; to seperate them!)</p>
  <p><input type="submit" value="OK" name="formSubmit" /></p>
</form>

<?php show_copyright(); ?>

</body></html>
