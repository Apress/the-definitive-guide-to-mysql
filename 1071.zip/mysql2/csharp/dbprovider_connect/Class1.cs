using System;
using eInfoDesigns.dbProvider.MySqlClient;

namespace odbc_connect {
  class mainclass         {
    [STAThread]
    static void Main(string[] args) {
      DbProviderTest tst = new DbProviderTest();
      tst.ReadPublishersDataset();
      Console.WriteLine("Return dr�cken");
      Console.ReadLine();
    }
  }

  class DbProviderTest {
    MySqlConnection myconn;

    public DbProviderTest() {     // use constructor to connect
      myconn = new MySqlConnection(
        "Data Source=localhost;Initial Catalog=mylibraryodbc;" + 
        "User ID=root;Password=saturn;Use Compression=true");
      myconn.Open();
    }

    public void ReadPublishersDataset() {
      MySqlCommand com = new MySqlCommand( 
        "SELECT publID, publName FROM publishers ORDER BY publName", myconn);
      MySqlDataReader dr = (MySqlDataReader)com.ExecuteReader();
      while(dr.Read()) {
        Console.WriteLine("id: {0} name: {1}", dr["publID"], dr["publName"]);
      }
      dr.Close();
    }
  }
}
