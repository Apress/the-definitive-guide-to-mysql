<?php {  // pictures/showpic.php?id=n     -*- C++ -*- 
  include("connect.inc.php");

  // get id; exit if no id
  $id = array_item($_GET, 'id');
  if(!$id) exit;

  // connect to MySQL, query for picture
  $connID = connect_to_picdb();
  $result = @mysql_query(
    "SELECT image, type FROM images WHERE id = $id");
  if(!$result) exit;

  // show picture
  $row = @mysql_fetch_object($result);
  if(!$row) exit;
  header($row->type);
  echo $row->image;
} ?>

