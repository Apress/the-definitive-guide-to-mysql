<?php // file myforum/forumlogout.php     -*- C++ -*- 

session_start();
unset($_SESSION['sesUserID']);
unset($_SESSION['$sesUserName']);
header("Location: ./forumlogin.php");
exit;

?>

