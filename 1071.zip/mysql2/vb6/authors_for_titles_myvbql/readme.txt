to make this example work:

- myvbql.dll must be registered in the registry. This can be done 
  in the VB6 development environment by first removing and then adding
  a reference to myvbql.dll 

- libmysql.dll must be in the same directory as the *.exe (for 
  compiled programs) or in the same directory as vb6.exe (to
  develop programs)