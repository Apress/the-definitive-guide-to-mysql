<?php    // file myforum/forumnewlogin.php     -*- C++ -*- --

// create a new login to myforum 
// form variables: formUser, formEMail, formPassword1 and -2

// include some standard functions
include("myforumconnect.inc.php");

// form variables
$formSubmit    = array_item($_POST, 'formSubmit');
$formPassword1 = array_item($_POST, 'formPassword1');
$formPassword2 = array_item($_POST, 'formPassword2');
$formUser      = array_item($_POST, 'formUser');
$formEMail     = array_item($_POST, 'formEMail');

// get rid of magic quotes
if(get_magic_quotes_gpc()) {
  $formPassword1 = stripslashes($formPassword1);
  $formPassword2 = stripslashes($formPassword2);
  $formUser      = stripslashes($formUser); 
  $formEMail     = stripslashes($formEMail);  }

// session management
session_start();
header("Cache-control: private"); // allow backspace in forms
if(SID) {
  $sid1 = "?" . SID;
  $sid2 = "&" . SID; }
else {
  $sid1=""; $sid2=""; }

// connect to database
$connID = connect_to_myforum();

// main code starts here ------------------------------

// set to 1 if an input error is detected
$wrongName = 0;      // per default, everything is fine 
$wrongEMail = 0;     // (these assignments avoid 'undefined
$wrongPassword = 0;  // variables' warnings)

// test if form data has been passed
if($formSubmit=="OK") {
  $formUser = trim($formUser);
  $formEMail = trim($formEMail);
  $formPassword1 = trim($formPassword1);
  $formPassword2 = trim($formPassword2);

  // test if username is unique 
  if($formUser) {
    $result = 
      mysql_query("SELECT userID, userName FROM users " .
                  "WHERE userName = '" . addslashes($formUser) . 
                  "' ");
    if(mysql_num_rows($result)==1) 
      $wrongName = 1;
  } 
  else 
    $wrongName = 1;  // no name specified

  // test if email address has been specified
  if(!$formEMail)
    $wrongEMail=1;

  // test if password has been specified and 
  // both passwords are identical
  if($formPassword1=="" or $formPassword1!=$formPassword2)
    $wrongPassword=1;

  // ok?
  if(!($wrongName || $wrongPassword || $wrongEMail)) {
    // save username and password, get ID, change to forumlist.php
    mysql_query("INSERT INTO users (userName, email, password) " .
                "VALUES ('" . addslashes($formUser) . "', '" . 
                addslashes($formEMail) . "', " .
                "    PASSWORD('" . addslashes($formPassword1) . "'))");
    $_SESSION['sesUserID']   = mysql_insert_id();
    $_SESSION['sesUserName'] = $formUser;
    // change to forumlist.php
    header("Location: forumlist.php$sid1");
    exit;
  }
  // else show form again
}




?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html><head>
  <meta http-equiv="Content-Type" 
        content="text/html; charset=iso-8859-1" />
  <title>PHP Programming, Get a new account (myforum database)</title>
</head><body>
<h2>Get a new account for the <i>myforum</i> discussion forum</h2>

<p>Please specify your username, your email address and your password
(twice to avoid typos).</p>

<?php

// show error message if previous try failed

if($wrongName) 
  echo '<p><font color="#ff0000">The username you ', 
  "specified is either empty or already in use. ",
  "Please use another one.</font></p>\n"; 
if($wrongEMail) 
  echo '<p><font color="#ff0000">Please specify ',
  " your email address.</font></p>\n"; 
if($wrongPassword) 
  echo '<p><font color="#ff0000">Please specify two ', 
  "identical passwords.</font></p>\n"; 

?> 

<form method="post" action="forumnewlogin.php<?php echo $sid1;?>">
<p><table>
<tr><td>Username:</td>
    <td><input name="formUser" size="30" maxlength="30"
         value="<?php echo htmlspecialchars($formUser); ?>" /></td>
<tr><td>Email address:</td>
    <td><input name="formEMail" size="30" maxlength="30" 
         value="<?php echo htmlspecialchars($formEMail); ?>" /></td>
<tr><td>Password: </td>
    <td><input type="password" name="formPassword1" 
         size="30" maxlength="30"
         value="<?php echo htmlspecialchars($formPassword1); ?>" /></td>
<tr><td>Password (again): </td>
    <td><input type="password" name="formPassword2" 
         size="30" maxlength="30"
         value="<?php echo htmlspecialchars($formPassword2); ?>" /></td>
<tr><td></td>
    <td><input type="submit" value="OK" name="formSubmit" /></td>
</table></p>
</form>

<?php show_copyright(); ?>

</body></html>
