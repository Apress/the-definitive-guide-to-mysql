<?php    // file forum/forumlogin.php     -*- C++ -*- --

// login to the myforum discussion board
// form variables: formUser, formPassword, formSubmit

// include some standard functions
include("myforumconnect.inc.php");

$formSubmit    = array_item($_POST, 'formSubmit');
$formPassword  = array_item($_POST, 'formPassword');
$formUser      = array_item($_POST, 'formUser');

// we need to make sure we have magic quotes
if(!get_magic_quotes_gpc()) {
  $formPassword = addslashes($formPassword);
  $formUser     = addslashes($formUser); }

// session management
session_start();
header("Cache-control: private"); // allow backspace in forms
$_SESSION['sesUserID']   = '';    // this is a login page,
$_SESSION['sesUserName'] = '';    // so delete prev. data!

// sid1/-2 help to build URLs if cookies are disabled
if(SID) {
  $sid1 = "?" . SID;
  $sid2 = "&" . SID; }
else {
  $sid1=""; $sid2=""; }


// connect to database
$connID = connect_to_myforum();

// main code starts here ------------------------------

// test if form data has been passed
if($formSubmit) {
  $result = 
    mysql_query("SELECT userID, userName FROM users " .
                "WHERE userName = '$formUser' " .
                "  AND password = PASSWORD('$formPassword')");
  // user found
  if(mysql_num_rows($result)==1) {
    $_SESSION['sesUserID']   = mysql_result($result, 0, 0);
    $_SESSION['sesUserName'] = mysql_result($result, 0, 1);
    // change to forumlist.php
    header("Location: forumlist.php$sid1");
    exit;
  }
}


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html><head>
  <meta http-equiv="Content-Type" 
        content="text/html; charset=iso-8859-1" />
  <title>PHP Programming, forum login (myforum database)</title>
</head><body>
<h2>Login to the <i>myforum</i> discussion forum</h2>

<?php

// show error message if previous try failed
if($formSubmit and empty($userID)) 
  echo '<p><font color="#ff0000">Username or password ', 
    "are invalid. Please try again.</font></p>\n";

?> 

<p>Please specify your username and password. (For testing purposes,
you may login using <i>test</i> as username and <i>secret</i> as
password.)</p>

<p>If you are a new user, please <a href="forumnewlogin.php">open a
new user account</a>.  If you only want to read the discussion groups
(but don't intend to write messages yourself), you don't need to
login and can proceed directly to the <a href="forumlist.php">list
of forums</a>.</p>

<form method="post" action="forumlogin.php">
<p><table>
<tr><td>Username:</td>
    <td><input name="formUser" size="30" 
               maxlength="30" /></td>
<tr><td>Password:</td>
    <td><input type="password" name="formPassword" 
               size="30" maxlength="30" /></td>
<tr><td></td>
    <td><input type="submit" value="Login" 
               name="formSubmit" /></td>
</table></p>
</form>

<?php show_copyright(); ?>

</body></html>
