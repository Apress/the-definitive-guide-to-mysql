<?php  // general/mysql-test.php     -*- C++ -*- ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html><head>
<title>Test PHP and MySQL</title>
</head><body>

<?php

$mysqluser="root";         // username
$mysqlpasswd="";           // password
$mysqlhost="localhost";    // name of computer MySQL is running
$connID = mysql_connect($mysqlhost, $mysqluser, $mysqlpasswd);
$result=mysql_list_dbs();
echo "<p>Databases at this MySQL server</p>\n";
echo "<p>";
while($row = mysql_fetch_row($result)) {
  echo "<br /><i>$row[0]</i>\n"; }
echo "</p>";
?>

</body></html>
