<?php    //  -*- C++ -*- 

// file mylibrary/mylibrarypassword.inc.php

// in order to increase the security of this project,
// move mylibrarypassword.inc.php to another directory
// which is protected against general download by .htaccess
// and change the include line in mylibraryconnect.inc.php
// accordingly

$mysqluser   = "root";      // username
$mysqlpasswd = "";          // password
$mysqlhost   = "localhost"; // name of computer MySQL is running
$mysqldbname = "mylibrary"; // name of database

?>
