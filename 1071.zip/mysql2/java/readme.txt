Diese Beispiele geh�ren zum Buch

  Michael Kofler: MySQL, 2. Auflage
  deutsche Ausgabe: Addison-Wesley Germany

Dieses Verzeichnis enth�lt einige Java-Beispielprogramme. Sie m�ssen jeweils den Benutzernamen und das Passwort �ndern (in der Zeile: conn = DriverManager.getConnection ...).

Das Unterverzeichnis mytest enth�lt JSP-Beispiele. Weitere Infos k�nnen Sie einer eigenen readme-Datei entnehmen.

Alles weitere siehe Kapitel 15!

----------------

Theses samples are part of the book

  Michael Kofler: MySQL, 2nd edition
  english edition: apress

This directory contains a few Java samples. You have to change the username and password to make them work (in the line: conn = DriverManager.getConnection ...). Then you must compile the files using JDK 1.3 or higher. 

The subdirectory mytest contains JSP samples, see the seperate readme.txt.

For more information, see chapter 15!

---------------

(c) 2001, 2002, 2003 Michael Kofler

