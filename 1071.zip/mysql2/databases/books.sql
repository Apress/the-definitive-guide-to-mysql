-- MySQL dump 9.07
--
-- Host: localhost    Database: books
---------------------------------------------------------
-- Server version	4.0.12-nt-log

--
-- Table structure for table 'author'
--

CREATE TABLE author (
  authorID int(11) NOT NULL auto_increment,
  author varchar(60) NOT NULL default '',
  PRIMARY KEY  (authorID)
) TYPE=MyISAM;

--
-- Dumping data for table 'author'
--

INSERT INTO author VALUES (1,'Kofler M.');
INSERT INTO author VALUES (2,'Kramer D.');
INSERT INTO author VALUES (3,'Orfali R.');
INSERT INTO author VALUES (4,'Harkey D.');
INSERT INTO author VALUES (5,'Edwards E.');
INSERT INTO author VALUES (6,'Ratschiller T.');
INSERT INTO author VALUES (7,'Gerken T.');
INSERT INTO author VALUES (14,'King T.');
INSERT INTO author VALUES (13,'Reese G.');
INSERT INTO author VALUES (12,'Yarger R.J.');

--
-- Table structure for table 'publisher'
--

CREATE TABLE publisher (
  publisherID int(11) NOT NULL auto_increment,
  publisher varchar(60) NOT NULL default '',
  PRIMARY KEY  (publisherID)
) TYPE=MyISAM;

--
-- Dumping data for table 'publisher'
--

INSERT INTO publisher VALUES (1,'Addison-Wesley');
INSERT INTO publisher VALUES (2,'apress');
INSERT INTO publisher VALUES (3,'New Riders');
INSERT INTO publisher VALUES (4,'O\'Reilly & Associates');

--
-- Table structure for table 'rel_title_author'
--

CREATE TABLE rel_title_author (
  titleID int(11) NOT NULL default '0',
  authorID int(11) NOT NULL default '0',
  PRIMARY KEY  (titleID,authorID)
) TYPE=MyISAM;

--
-- Dumping data for table 'rel_title_author'
--

INSERT INTO rel_title_author VALUES (1,1);
INSERT INTO rel_title_author VALUES (2,1);
INSERT INTO rel_title_author VALUES (2,2);
INSERT INTO rel_title_author VALUES (3,3);
INSERT INTO rel_title_author VALUES (3,4);
INSERT INTO rel_title_author VALUES (3,5);
INSERT INTO rel_title_author VALUES (4,6);
INSERT INTO rel_title_author VALUES (4,7);
INSERT INTO rel_title_author VALUES (9,12);
INSERT INTO rel_title_author VALUES (9,13);
INSERT INTO rel_title_author VALUES (9,14);

--
-- Table structure for table 'title'
--

CREATE TABLE title (
  titleID int(11) NOT NULL auto_increment,
  title varchar(100) NOT NULL default '',
  publisherID int(11) NOT NULL default '0',
  year int(11) NOT NULL default '0',
  PRIMARY KEY  (titleID)
) TYPE=MyISAM;

--
-- Dumping data for table 'title'
--

INSERT INTO title VALUES (1,'Linux, 5th ed.',1,2000);
INSERT INTO title VALUES (2,'Definitive Guide to Excel VBA',2,2000);
INSERT INTO title VALUES (3,'Client/Server Survival Guide',1,1997);
INSERT INTO title VALUES (4,'Web Application Development with PHP 4.0',3,2000);
INSERT INTO title VALUES (7,'MySQL',1,2001);
INSERT INTO title VALUES (9,'MySQL & mSQL',4,1999);

