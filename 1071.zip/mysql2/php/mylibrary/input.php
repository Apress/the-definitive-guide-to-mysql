<?php // file mylibrary/input.php     -*- C++ -*- 

// include some standard functions
include("mylibraryconnect.inc.php");


// ------------------------------------- functions -------------

// add slashes for ', ", \ and \0 and enclose in ' -------------

function sql_str($x) {
  return "'" . addslashes($x) . "'";
}

// return a string enclosed in ' or NULL -----------------------

function str_or_null($x) {
  if(trim($x)=="")
    return("NULL");
  else
    return(sql_str(trim($x)));
}

// return a number or NULL -------------------------------------

function num_or_null($x) {
  if(empty($x))
    return("NULL");
  else
    return($x);
}

// puts last name to beginning of string  ----------------------

// the function assumes that the string is given in 'natural'
// order, i.e. with the last name last; the last name is 
// moved to the beginning of the string

// "Peter Smith"         --> "Smith Peter"
// "John F. Kennedy"     --> "Kennedy J.F."
// "first last"          --> "last first"
// "first1 first2 last"  --> "last first1 first2"

// leave unchanged if no blank 
// "Smith"               --> "Smith"

// also leave unchanged if dot at end of string
// (rationale: a dot is normally not used at the end
//  of a last name; therefore, the string is likeley
//  already with the last name first and needs not
//  to be changed)
// "Smith P."            --> "Smith P."

function last_name_first($x) {
  $x = trim($x);
  // return unchanged if string ends with .
  if(substr($x, -1) == ".") return($x);  
  // return unchanged if no blanks
  if(!$pos = strrpos($x, " ")) return($x);
  // return swapped parts
  return(trim(substr($x, $pos+1) . " " . substr($x, 0, $pos)));
}

// puts first part of string to the end  -----------------------

// the function assumes that the string contains a name in 
// 'database order', i.e. with the last name first; to
// display the name in a more natural way, the last name
// is moved to the end of the string

// "Smith Peter"         --> "Peter Peter"
// "Kennedy John F."     --> "John F. Kennedy"
// "last first"          --> "first last"
// "last first1 first2"  --> "first1 first2 last"

// leave unchanged if no blank 
// "Smith"               --> "Smith"

function last_name_last($x) {
  $x = trim($x);
  // return unchanged if no blanks
  if(!$pos = strpos($x, " ")) return($x);
  // return swapped parts
  return(trim(substr($x, $pos+1) . " " . substr($x, 0, $pos)));
}


// builds a selection list for a form --------------------------
// formname: name of the select list
// sql: contains SELECT query; the first parameter has to be ID,
//      the second one the name

function build_select_list($formname, $sql, $defaultitem) {
  $result = mysql_query($sql);
  echo '<select name="', $formname, '" size="1">', "\n";
  echo '<option value="none">(choose)</option>', "\n";
  while($row=mysql_fetch_row($result)) {
    echo "<option ";
    if($defaultitem==$row[0]) echo 'selected="selected" ';
    echo "value=\"$row[0]\"> ", htmlentities($row[1]), 
      "</option>\n";
  }
  echo "</select>\n";
  mysql_free_result($result);
}

// builds hierarchical category selection list for a form ----------

function build_categories_select($defaultitem) {
  $result =
    mysql_query("SELECT catID, catName, hierIndent " .
                "FROM categories " .
                "ORDER BY hierNr");
  echo '<select name="formCategory" size="1">', "\n";
  echo '<option value="none">(choose)</option>', "\n";
  while($row=mysql_fetch_object($result)) {
    echo "<option ";
    if($defaultitem==$row->catID) echo 'selected="selected" ';
    echo "value=\"$row->catID\">",
      $row->hierIndent>0 ? 
        str_repeat("&nbsp;&nbsp;&nbsp;", $row->hierIndent) : "",
      htmlentities($row->catName), "</option>\n";
  }
  echo "</select>\n";
  mysql_free_result($result);
}

// build option list for publisher names (stage 2) -----------------

function show_publisher_options($publname) {
  // if empty, show empty input field again
  $publname=trim($publname);
  if($publname=="") {
    echo '<tr><td>Publisher:</td>', "\n",
      '<td><input name="formPublisher" size="60" maxlength="100" ',
      'value="" /></td></tr>', "\n";
    echo '<input type="hidden" name="formPublType" value="0" />', "\n";
    return;
  }

  // test if publisher is already known as is
  $result = mysql_query("SELECT publName FROM publishers " .
                        "WHERE publName = " . sql_str($publname) . 
                        " LIMIT 2");
  if(mysql_num_rows($result)==1) {
    $known_publisher = 1;
    $publname = mysql_result($result, 0, 0);
    mysql_free_result($result);
  }

  // try to find a list of similar publishers
  else {
    $publpattern = substr($publname, 0, 6) . '%';
    $result = 
      mysql_query("SELECT publID, publName FROM publishers " .
                  "WHERE publName LIKE " . sql_str($publpattern) . " " .
                  "ORDER BY publName LIMIT 20");
  }

  // show form data
  // publisher is already known
  if(isset($known_publisher)) {
    echo "<tr><td>Known Publisher:</td>\n",
      '<td><input name="formPublisher" size="60" maxlength="100" ',
      'value="', htmlspecialchars($publname), '" />', "\n</td></tr>\n";
    echo '<input type="hidden" name="formPublType" value="1" />', "\n";
  }
  else {

    // new publisher, no similar publishers found
    if(!mysql_num_rows($result)) {
      echo "<tr><td>New Publisher:</td>\n",
        '<td>Please specify full name. Please use correct spelling.', "\n", 
        '<br /><input name="formPublisher" size="60" maxlength="100" ',
        'value="', htmlspecialchars($publname), '" />', "\n</td></tr>\n";
      echo '<input type="hidden" name="formPublType" value="2" />', "\n";
    }

    // perhaps new publisher, show also similar publishers
    // use a new table to achieve proper typesetting
    else {
      echo "<tr><td>Publisher:</td>\n",
        '<td><table cellpadding="2">', "\n";
      echo '<tr><td><input type="radio" name="formPublRadio" value="new" /></td>',
        '<td>New Publisher (Please specify full name. Please use ',
        'correct spelling.)', "\n",
        '<input name="formPublisher" size="60" maxlength="100" ',
        'value="', htmlspecialchars($publname), '" /></td></tr>', "\n";
      // show list of similar publishers; 
      // if only one was found, select this option
      // in publNames and publIDs a list of all names and IDs
      // is build; these lists are saved in hidden fields to
      // make it possible to restore the options later
      $publNames="";
      $publIDs="";
      while($row=mysql_fetch_object($result)) {
        echo '<tr><td><input type="radio" name="formPublRadio" ',
          mysql_num_rows($result)==1 ? 'checked="checked" ' : '',
          'value="', $row->publID, '" /></td>',
          '<td>', $row->publName, "</td></tr>\n";
        $publNames .= ";" . $row->publName;
        $publIDs .= ";" . $row->publID;
      }
      echo "</table></td>\n</tr>\n";
      // save additional hidden information 
      echo '<input type="hidden" name="formPublType" value="3" />', "\n";
      echo '<input type="hidden" name="formPublNames" value="', 
        htmlspecialchars(substr($publNames, 1)), '" />', "\n";
      echo '<input type="hidden" name="formPublIDs" value="', 
        substr($publIDs, 1), '" />', "\n";
    }
    mysql_free_result($result);
  }
}

// restore publisher option (stage 2 second try) -------------------

function restore_publisher_options() {
  global $formPublisher, $formPublType, $formPublRadio, 
    $formPublNames, $formPublIDs;

  // no publisher
  if($formPublType==0) {
    echo "<tr><td>Publisher:</td>\n",
      '<td><input name="formPublisher" size="60" maxlength="100" ',
      'value="', htmlspecialchars($formPublisher), '" />', "</td>\n</tr>\n";
    echo '<input type="hidden" name="formPublType" value="0" />', "\n";
  }
  // one known publisher
  elseif($formPublType==1) {
    echo "<tr><td>Known Publisher:</td>\n",
      '<td><input name="formPublisher" size="60" maxlength="100" ',
      'value="', htmlspecialchars($formPublisher), '" />', "</td>\n</tr>\n";
    echo '<input type="hidden" name="formPublType" value="1" />', "\n";
  }
  // unknown publisher
  elseif($formPublType==2) {
    echo "<tr><td>New Publisher:</td>\n",
      '<td>Please specify full name. Please use correct spelling.', "\n",
      '<br /><input name="formPublisher" size="60" maxlength="100" ',
      'value="', htmlspecialchars($formPublisher), '" />', "</td>\n</tr>\n";
    echo '<input type="hidden" name="formPublType" value="2" />', "\n";
  }
  // list of publishers
  else {
    echo "<tr><td>Publisher:</td>\n",
      '<td><table cellpadding="2">', "\n";
    echo '<tr><td><input type="radio" name="formPublRadio" ',
      $formPublRadio=="new" ? 'checked="checked" ' : '', 
      'value="new" /></td> ',
      '<td>New Publisher (Please specify full name. Please use ',
      'correct spelling.)', "\n",
      '<input name="formPublisher" size="60" maxlength="100" ',
      'value="', htmlspecialchars($formPublisher), '"></td></tr>', "\n";
    // $formPublNames and $formPublIDs contain names and IDs
    $publNamesArray = explode(";", $formPublNames);
    $publIDsArray = explode(";", $formPublIDs);
    for($i=0; $i < sizeof($publNamesArray); $i++) {
      echo '<tr><td><input type="radio" name="formPublRadio" ',
        $formPublRadio==$publIDsArray[$i] ? 'checked="checked" ' : '',
        'value="', $publIDsArray[$i], '" /></td>',
        '<td>', htmlentities($publNamesArray[$i]), "</tr>\n";
    }
    echo "</table></td>\n</tr>\n";
    // save additional infos
    echo '<input type="hidden" name="formPublType" value="3" />', "\n";
    echo '<input type="hidden" name="formPublNames" value="', 
      htmlspecialchars($formPublNames), '" />', "\n";
    echo '<input type="hidden" name="formPublIDs" value="', 
      $formPublIDs, '" />', "\n";
  }
}

// build option lists for all author names (stage 2) ---------------

function show_authors_options($formAuthors) {
  $authArray = explode(";", $formAuthors);
  $authCount = 0;

  // loop through all authors
  while($i = each($authArray)) {
    $known_author = 0;
    $author = trim($i[1]);
    if($author) {
      $authCount++;
      
      // assumes that $author contains natural name (last name last);
      // move last name to beginning of string (database order of names)
      $authorDB = last_name_first($author);

      // test whether author is already known as is
      $result1 = mysql_query("SELECT authName FROM authors " .
                             "WHERE authName = " . sql_str($authorDB) .
                             " LIMIT 2");
      if(mysql_num_rows($result1)==1) {
        $known_author=1;
        $authorDB = mysql_result($result1, 0, 0);
        $author = last_name_last($authorDB);
      }
      // perhaps the last name was given first; try again 
      // without swapping last and first name 
      else {
        $result2 = mysql_query("SELECT authName FROM authors " .
                               "WHERE authName = " . sql_str($author) . 
                               " LIMIT 2");
        if(mysql_num_rows($result2)==1) {
          $known_author=1;
          $authorDB = mysql_result($result2, 0, 0);
          $author = last_name_last($author);
        }
          
        // try to find a list of similar authors
        else {
          $authpattern=substr($authorDB, 0, 6) . '%';
          $result3 = 
            mysql_query("SELECT authID, authName FROM authors " .
                        "WHERE authName LIKE " . sql_str($authpattern) .
                        " ORDER BY authName LIMIT 15");
        }
        mysql_free_result($result2);
      }
      mysql_free_result($result1);
       
      // show form data
      // names for input fields
      $inputname =   '"formAuthor' . $authCount . '"';
      $radioname =   '"formAuthorRadio' . $authCount . '"';
      $typename =    '"formAuthorType' . $authCount . '"';
      $hiddenNames = '"formAuthorNames' . $authCount . '"';
      $hiddenIDs =   '"formAuthorIDs' . $authCount . '"';

      // author is already known
      if($known_author) {
        echo "<tr><td>Known Author $authCount:</td>\n",
          '<td><input name=', $inputname, ' size="60" maxlength="100" ',
          'value="', htmlspecialchars($author), '" />', "</td>\n</tr>\n";
        echo '<input type="hidden" ', "name=$typename ", 
          'value="1" />', "\n";
      }

      else {
        // new author, no similar author found
        if(!mysql_num_rows($result3)) {
          echo "<tr><td>New Author $authCount:</td>\n",
            '<td>Please use correct spelling. Last name last, i.e. Stephen King!', "\n",
            '<br /><input name=', $inputname, ' size="60" maxlength="100" ',
            'value="', htmlspecialchars($author), '" />', "</td>\n</tr>\n";
          echo '<input type="hidden" ', "name=$typename ", 
            ' value="2" />', "\n";
        }

        // perhaps new author, but show also similar authors
        // use a new table to achieve proper typesetting
        else {
          echo "<tr><td>Author $authCount:</td>\n",
            '<td><table cellpadding="2">', "\n";
          echo '<tr><td><input type="radio" ',
            "name=$radioname ", ' value="new" />', "\n",
            '<td>New Author (Please use correct spelling. ',
            'Last name last, i.e. Stephen King!) ', "\n",
            '<input name=', $inputname, ' size="60" maxlength="100" ',
            'value="', htmlspecialchars($author), '" /></td></tr>', "\n";
          // show list of similar authors;
          // if only one was found, select this option;
          // in authNames and authIDs a list of all names and IDs
          // is build; these lists are saved in hidden fields to
          // make it possible to restore the options later
          $authNames="";
          $authIDs="";
          while($row=mysql_fetch_object($result3)) {
            echo '<tr><td><input type="radio" ',
              "name=$radioname ", 
              mysql_num_rows($result3)==1 ? 'checked="checked" ' : '',
              'value="', $row->authID, '" /></td><td>', 
              htmlentities(last_name_last($row->authName)), 
              "</td></tr>\n";
            $authNames .= ";" . $row->authName;
            $authIDs .= ";" . $row->authID;
          }
          echo "</table></td>\n</tr>\n";
          // save names and IDs in hidden fields
          echo '<input type="hidden" ', 
            "name=$typename ", 
            'value="3" />', "\n";
          echo '<input type="hidden" ', 
            "name=$hiddenNames ", 
            'value="', htmlspecialchars(substr($authNames, 1)), 
            '" />', "\n";
          echo '<input type="hidden" ', 
            "name=$hiddenIDs ", 
            'value="', substr($authIDs, 1), '" />', "\n";
        }
        mysql_free_result($result3);
      }
    }  // if($author)
  }    // loop through all authors
  // save nr of authors in hidden field
  echo '<input type="hidden" name="formAuthorsCount" value="', 
    $authCount, '" />', "\n";
}

// restore authors part of form (stage 2 second try) ---------------

function restore_authors_options() {
  global $formAuthors, $formAuthorsCount;
  for($authCount=1; $authCount<=$formAuthorsCount; $authCount++)
    global ${'formAuthorType' . $authCount}, 
      ${'formAuthor' . $authCount},
      ${'formAuthorRadio' . $authCount},
      ${'formAuthorNames' . $authCount},
      ${'formAuthorIDs' . $authCount};

  // loop through all authors
  for($authCount=1; $authCount<=$formAuthorsCount; $authCount++) {
    // read form variables ($formAuthor<n> --> $author)
    $author =      ${'formAuthor' . $authCount};
    $authorRadio = ${'formAuthorRadio' . $authCount};
    $authorType =  ${'formAuthorType' . $authCount};
    $authNames =   ${'formAuthorNames' . $authCount};
    $authIDs  =    ${'formAuthorIDs' . $authCount};

    // name attributes for form input fields
    $inputname =   '"formAuthor' . $authCount . '"';
    $radioname =   '"formAuthorRadio' . $authCount . '"';
    $typename =    '"formAuthorType' . $authCount . '"';
    $hiddenNames = '"formAuthorNames' . $authCount . '"';
    $hiddenIDs =   '"formAuthorIDs' . $authCount . '"';

    // author is already known
    if($authorType==1) {
      echo "<tr><td>Known Author $authCount:</td>\n",
        '<td><input name=', $inputname, ' size="60" maxlength="100" ',
        'value="', htmlspecialchars($author), '" />', "</td>\n</tr>\n";
      echo '<input type="hidden" ', "name=$typename ", 
        ' value="1" />', "\n";
    }
    // author is unknown
    elseif($authorType==2) {
      echo "<tr><td>New Author $authCount:</td>\n",
        '<td>Please specify full name. Please use correct spelling.', "\n",
        '<br /><input name=', $inputname, ' size="60" maxlength="100" ',
        'value="', htmlspecialchars($author), '" />', "</td>\n</tr>\n";
      echo '<input type="hidden" ', "name=$typename ", 
        'value="2" />', "\n";
    }
    // author unknown, but similar authors known
    else {
      echo "<tr><td>Author $authCount:</td>\n",
        '<td><table cellpadding="2">', "\n";
      echo '<tr><td><input type="radio" ',
        "name=$radioname ", 
        $authorRadio=="new" ? 'checked="checked" ' : '', 
        'value="new" /></td>', "\n",
        '<td>New Author (Please specify full name. Please use ',
        'correct spelling.)', "\n",
        '<input name=', $inputname, ' size="60" maxlength="100" ',
        'value="', htmlspecialchars($author), '" /></td></tr>', "\n";
      // show list of similar publishers; 
      $authNamesArray = explode(";", $authNames);
      $authIDsArray = explode(";", $authIDs);
      for($i=0; $i < sizeof($authNamesArray); $i++) {
        echo '<tr><td><input type="radio" ',
          "name=$radioname ",
          $authorRadio==$authIDsArray[$i] ? 'checked="checked" ' : '',
          'value="', $authIDsArray[$i], '" /></td>',
          '<td>', htmlentities(last_name_last($authNamesArray[$i])), 
          "</td></tr>\n";
          }
      echo "</table></td>\n</tr>\n";
      // add hidden information
      echo '<input type="hidden" ', "name=$typename ", 
        'value="3">', "\n";
      echo '<input type="hidden" ', "name=$hiddenNames ", 
        ' value="', htmlspecialchars($authNames), '" />', "\n";
      echo '<input type="hidden" ', "name=$hiddenIDs ", 
        '" value="', $authIDs, '" />', "\n";
    }
  }  // end authors loop
  // save nr of authors in hidden field
  echo '<input type="hidden" name="formAuthorsCount" value="', 
    $formAuthorsCount, '" />', "\n";
}


// validation for data from stage 1 form ------
// show error messages, return error count

function validate_stage1() {
  global $formTitle, $formEdition, $formYear;

  $errstart = '<br /><font color="#ff0000">';
  $errend = "</font>\n";
  $errors = 0;
  echo "<p>";

  // validate title
  if(!trim($formTitle)) {
    echo $errstart, "Please enter an <i>title</i>.\n", $errend; 
    $errors++;
  }
  
  // validate edition
  if($formEdition and 
     (!is_numeric($formEdition) or intval($formEdition)<1)) {
    echo $errstart, "<i>Edition</i> needs to be either empty or an  ",
      "integer greater or equal 1.", $errend;
    $errors++;
  }

  // validate publishing year
  // publishing year must not be larger then current year + 1
  // (31536000 are the seconds of a year)
  if($formYear and 
     (!is_numeric($formYear) or 
      intval($formYear) > date("Y", time()+31536000))) {
    echo $errstart, "<i>Publishing year</i> needs to be either ",
      "empty or a 4-digit integer number not larger than ", 
      date("Y", time()+31536000), ".", $errend;
    $errors++;
  }

  echo "</p>\n";
  return($errors);
}



// validate input from stage 2 form --------------------------------
// show error messages in HTML document
// return no. of errors

function validate_stage2() {
  // make all form variables global
  global $formTitle, $formSubtitle, $formAuthors, $formEdition, 
    $formCategory, $formYear, $formLanguage, $formISBN, 
    $formComment, $formAuthorsCount, $formPublisher, $formPublType, 
    $formPublRadio, $formPublNames, $formPublIDs;
  for($authCount=1; $authCount<=$formAuthorsCount; $authCount++)
    global ${'formAuthorType' . $authCount}, 
      ${'formAuthor' . $authCount},
      ${'formAuthorRadio' . $authCount},
      ${'formAuthorNames' . $authCount},
      ${'formAuthorIDs' . $authCount};

  // do same validation as for stage 1
  $errors = validate_stage1();

  // do additional validation
  $errstart = '<br /><font color="#ff0000">';
  $errend = "</font>\n";
  echo "<p>";

  // validate authors
  // if there are no options, is a name given?
  // if there are options, is one choosen?
  // if there are options and option "new" is choosen, is a name given?
  for($authCount=1; $authCount<=$formAuthorsCount; $authCount++) {
    // read form variables ($formAuthor<n> --> $author)
    $author =      ${'formAuthor' . $authCount};
    $authorRadio = ${'formAuthorRadio' . $authCount};
    $authorType =  ${'formAuthorType' . $authCount};
    if(($authorType<3 and empty($author)) or
       ($authorType==3 and empty($authorRadio)) or
       ($authorType==3 and $authorRadio=="new" and empty($author))) {
      echo $errstart, "Please specify <i>author $authCount</i>.\n", $errend; 
      $errors++;
    }
  }

  // validate publisher
  // if there are no options, is a name given?
  // if there are options, is one choosen?
  // if there are options and option "new" is choosen, is a name given?
  if(($formPublType>0 and $formPublType<3 and empty($formPublisher)) or
     ($formPublType==3 and empty($formPublRadio)) or
     ($formPublType==3 and $formPublRadio=="new" and empty($formPublisher))) {
    echo $errstart, "Please specify a <i>publisher</i>.\n", $errend; 
    $errors++;
  }

  echo "</p>\n";
  return($errors);
}


// save data in database (end of stage 2) ----------------------

function save_data() {
  global $formTitle, $formSubtitle, $formEdition, 
    $formCategory, $formYear, $formLanguage, $formISBN, 
    $formComment, $formAuthorsCount, $formPublisher, $formPublType, 
    $formPublRadio, $formPublNames, $formPublIDs;
  for($authCount=1; $authCount<=$formAuthorsCount; $authCount++)
    global ${'formAuthorType' . $authCount}, 
      ${'formAuthor' . $authCount},
      ${'formAuthorRadio' . $authCount},
      ${'formAuthorNames' . $authCount},
      ${'formAuthorIDs' . $authCount};

  // save publisher:
  // publisher name given in text box
  $formPublisher = trim($formPublisher);
  if(($formPublType<3 or 
      ($formPublType==3 and $formPublRadio=="new")) 
     and !empty($formPublisher)) {
    // test if publisher is already known
    $result = 
      mysql_query("SELECT publID FROM publishers " .
                  "WHERE publName = " . sql_str($formPublisher));
    if(mysql_num_rows($result))
      $publID = mysql_result($result, 0, 0);
    // publisher is unknown: insert
    else {
      mysql_query("INSERT INTO publishers (publName) " .
                  "VALUES(" . sql_str($formPublisher) . ")");
      $publID = mysql_insert_id();
    }
    mysql_free_result($result);
  }
  // known publisher selected, $formPublRadio contains ID
  elseif($formPublType==3 and $formPublRadio!="new") {
    $publID = $formPublRadio;
  }
  // no publisher
  else
    $publID="";

  // save authors
  // loop through all authors
  $authCount=0;
  for($i=1; $i<=$formAuthorsCount; $i++) {
    $newID = "none";
    // read form variables ($formAuthor<n> --> $author)
    $author =      ${'formAuthor' . $i};
    $authorRadio = ${'formAuthorRadio' . $i};
    $authorType =  ${'formAuthorType' . $i};

    // assumes that $author contains natural name (last name last);
    // move last name to beginning of string (database order of names)
    $author = trim($author);
    $authorDB = last_name_first($author);

    // author is in text field
    if($author and $authorType<3 or $authorRadio=="new") {
      // test if author is already known
      $result = 
        mysql_query("SELECT authID FROM authors " .
                    "WHERE authName = " . sql_str($authorDB) .
                    "   OR authName = " . sql_str($author));
      if(mysql_num_rows($result)) 
        $newID = mysql_result($result, 0, 0);
      // author is unknown: insert
      else {
        mysql_query("INSERT INTO authors (authName) " .
                    "VALUES(" . sql_str($authorDB) . ")");
        $newID = mysql_insert_id();
      }
      mysql_free_result($result);
    }
    // known author selected, $authorRadio contains ID
    elseif ($authorRadio!="new")
      $newID = $authorRadio;

    // make sure no author is referred to twice
    if(isset($authIDs))
      for($j=0; $j<sizeof($authIDs); $j++)
        if($authIDs[$j]==$newID) {
          $newID="none"; break;
      }
    
    // save newID in $authIDs array
    if($newID!="none") {
      $authIDs[$authCount]=$newID;
      $authCount++;
    }
  } // end authors loop      

  // save title
  if($formCategory=="none") $formCategory="";
  if($formLanguage=="none") $formLanguage="";

  mysql_query("INSERT INTO titles (title, subtitle, " .
              "  edition, publID, catID, langID, year, " .
              "  isbn, comment) VALUES (" .
              sql_str(trim($formTitle)) .  ", " .
              str_or_null($formSubtitle) . ", " .
              num_or_null($formEdition) .  ", " .
              num_or_null($publID) .       ", " .
              num_or_null($formCategory) . ", " .
              num_or_null($formLanguage) . ", " .
              num_or_null($formYear) .     ", " .
              str_or_null($formISBN) .     ", " .
              str_or_null($formComment) . ")");
  $titleID = mysql_insert_id();

  // save rel_title_author
  $sql = "INSERT INTO rel_title_author " .
    "(titleID, authID, authNr) VALUES ";
  for($i=0; $i<$authCount; $i++) {
    if($i!=0) $sql .= ",";
    $sql .= "($titleID, $authIDs[$i], $i)";
  }
  mysql_query($sql);
}


// #################################################################
//
//                   main code starts here
//
// #################################################################


// connect to database
// show error message if no database connection

$connID = connect_to_mylibrary();

?>

<!-- start of html document if no connection error has happened -->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html><head>
  <meta http-equiv="Content-Type" 
        content="text/html; charset=iso-8859-1" />
  <title>PHP Programming, input title (mylibrary database)</title>
</head><body>
<h2>Input new title for the mylibrary database</h2>

<?php

// -------- main code starts here ----------------------------------

// avoid 'variable undefined' warnings
// error_reporting(error_reporting() & ~(E_WARNING | E_NOTICE) );

// remove \ in all variables coming from forms 
if(get_magic_quotes_gpc()) {
  while($i = each($_POST)) {
    $_POST[$i[0]] = stripslashes($i[1]);
  }
}

// retrieve FORM variables from $_POST
$formSubmit1     = array_item($_POST, 'formSubmit1');
$formTitle       = array_item($_POST, 'formTitle');
$formSubtitle    = array_item($_POST, 'formSubtitle');
$formAuthors     = array_item($_POST, 'formAuthors');
$formEdition     = array_item($_POST, 'formEdition');
$formCategory    = array_item($_POST, 'formCategory');
$formYear        = array_item($_POST, 'formYear');
$formLanguage    = array_item($_POST, 'formLanguage');
$formISBN        = array_item($_POST, 'formISBN');
$formComment     = array_item($_POST, 'formComment');

$formSubmit2      = array_item($_POST, 'formSubmit2');
$formAuthorsCount = array_item($_POST, 'formAuthorsCount');
$formPublisher    = array_item($_POST, 'formPublisher');
$formPublType     = array_item($_POST, 'formPublType');
$formPublRadio    = array_item($_POST, 'formPublRadio');
$formPublNames    = array_item($_POST, 'formPublNames');
$formPublIDs      = array_item($_POST, 'formPublIDs');

for($authCount=1; $authCount<=$formAuthorsCount; $authCount++) {
  ${'formAuthorType' . $authCount} = 
    array_item($_POST, 'formAuthorType' . $authCount);
  ${'formAuthor' . $authCount} = 
    array_item($_POST, 'formAuthor' . $authCount);
  ${'formAuthorRadio' . $authCount} = 
    array_item($_POST, 'formAuthorRadio' . $authCount);
  ${'formAuthorNames' . $authCount} = 
    array_item($_POST, 'formAuthorNames' . $authCount);
  ${'formAuthorIDs' . $authCount} = 
    array_item($_POST, 'formAuthorIDs' . $authCount);
}

// if both $formSubmit1 and $formSubmit2 are empty:
$stage=1;

// if form data from stage 1 has been submitted:

if($formSubmit1) {
  // validate formAuthors (only if from stage 1 form)
  // replace , by ;
  $formAuthors = str_replace(",", ";", $formAuthors);
  // test if formAuthor contains data; 
  // if formAuthor is empty, show stage 1 form again
  if(!trim(str_replace(";", "", $formAuthors))) {
    echo '<p><font color="#ff0000">You must specify ',
      "<i>authors</i> in stage 1.</font></p>\n";
    $stage=1;
  }
  // else do a validation and show warnings but show
  // show stage 2
  else {
    validate_stage1();
    $stage=2;
  }
} 

// if form data from stage 2 has been submitted
if($formSubmit2) {
  // do a better validation this time
  // if data is ok (0 errors): save, then back to stage 1 (next input!)
  // else: show stage 2 form again
  if(validate_stage2()==0) {
    save_data();
    echo "<p>Your last input has been saved and can be seen ",
      build_href("find.php", 
                 "sqlType=title&search=" . urlencode(trim($formTitle)), 
                 "here"), 
      ". ",
      "<br />You may now continue with the next title.</p>\n";
    $stage=1;
    // clear stage 1 input variables
    $formTitle = $formSubtitle = $formYear = $formISBN="";
    $formAuthors = $formPublisher = $formCategory = "";
    $formComment = $formLanguage = $formEdition = "";
  } else 
    $stage=2;
}


// display insert form (stage 1)

if($stage==1) {

?>

<h3>Input new title (stage 1)</h3>

<form method="POST" action="input.php">
<table>
<tr><td>Title: *</td>
    <td><input name="formTitle" size="60" maxlength="80"
               value="<?php echo htmlspecialchars($formTitle); ?>" /></td></tr>
<tr><td>Subtitle:</td>
    <td><input name="formSubtitle" size="60" maxlength="80"
               value="<?php echo htmlspecialchars($formSubtitle); ?>" /></td></tr>
<tr><td>Edition:</td>
    <td><input name="formEdition" size="2" maxlength="2"
               value="<?php echo htmlspecialchars($formEdition); ?>" /></td></tr>
<tr><td>Authors: *</td>
    <td><input name="formAuthors" size="60" maxlength="100"
               value="<?php echo htmlspecialchars($formAuthors); ?>" /></td></tr>
<tr><td>Publisher:</td>
    <td><input name="formPublisher" size="60" maxlength="100"
               value="<?php echo htmlspecialchars($formPublisher); ?>" /></td></tr>
<tr><td>Category:</td>
    <td><?php build_categories_select($formCategory); ?></td></tr>
<tr><td>Publishing year:</td>
    <td><input name="formYear" size=4 maxlength=4
               value="<?php echo htmlspecialchars($formYear); ?>" /></td></tr>
<tr><td>Language:</td>
    <td><?php build_select_list("formLanguage",
               "SELECT langID, langName FROM languages " .
               "ORDER BY langName", $formLanguage); ?></td></tr>
<tr><td>ISBN:</td>
    <td><input name="formISBN" size="15" maxlength="15"
               value="<?php echo htmlspecialchars($formISBN); ?>" /></td></tr>
<tr><td>Comment/Keywords:</td>
    <td><input name="formComment" size="60" maxlength="250"
               value="<?php echo htmlspecialchars($formComment); ?>" /></td></tr>
<tr><td></td>
    <td><input type="submit" value="OK, validate data" name="formSubmit1" /></td></tr>
</table>
</form>

<?php

} // end of if($stage==1)

// ------------------------------ show input form (stage 2)

if($stage==2) {
  
?>

<h3>Verify data (stage 2)</h3>

<form method="post" action="input.php">
<table cellpadding="5">
<tr><td>Title: *</td>
    <td><input name="formTitle" size="60" maxlength="80"
               value="<?php echo htmlspecialchars($formTitle); ?>" /></td></tr>
<tr><td>Subtitle:</td>
    <td><input name="formSubtitle" size="60" maxlength="80"
               value="<?php echo htmlspecialchars($formSubtitle); ?>" /></td></tr>
<tr><td>Edition:</td>
    <td><input name="formEdition" size="2" maxlength="2"
               value="<?php echo htmlspecialchars($formEdition); ?>" /></td></tr>

<?php 

if($formSubmit1)
  show_authors_options($formAuthors);
else
  restore_authors_options();

if($formSubmit1)
  show_publisher_options($formPublisher);
 else
  restore_publisher_options();
?>

<tr><td>Category:</td>
    <td><?php build_categories_select($formCategory); ?></td></tr>
<tr><td>Publishing year:</td>
    <td><input name="formYear" size="4" maxlength="4"
               value="<?php echo htmlspecialchars($formYear); ?>" /></td></tr>
<tr><td>Language:</td>
    <td><?php build_select_list("formLanguage",
               "SELECT langID, langName FROM languages " .
               "ORDER BY langName", $formLanguage); ?></td></tr>
<tr><td>ISBN:</td>
    <td><input name="formISBN" size="15" maxlength="15"
               value="<?php echo htmlspecialchars($formISBN); ?>" /></td></tr>
<tr><td>Comment/Keywords:</td>
    <td><input name="formComment" size="60" maxlength="250"
               value="<?php echo htmlspecialchars($formComment); ?>" /></td></tr>
<tr><td></td>
    <td><input type="submit" value="OK, save data" name="formSubmit2" /></td></tr>
</table>
</form>

<?php

} // end of if(stage==2)

?>

<hr />
<p><b>How to input data</b></p>
<ul>

<li><b>Two stage input:</b> Title input is done in two stages.  In the
first stage it is sufficient to specify only a few characters for
authors and publishers names already know to the database. For
authors, these characters have to describe the last name.  I.e. you
might try to specify only <i>kof</i> instead of <i>Michael Kofler</i>.
If there is more than one author/publisher matching, you can
choose the right one during the second stage. If the author/publisher
is unknown, you can still specify the full name in the second stage.

<li><p><b>Authors:</b> <b>Last name last, i.e. <i>Stephen
King</i>!</b> In stage 1 you may specify more than one author.  Use ;
or , to seperate names, i.e.: <i>Stephen King;Joanne K. Rowling</i></p></li>

<li><p><b>Required items:</b> Only items marked with a star * are
required.</p></li>
</ul>

<form method="post" action="input.php">
<input type="submit" value="Reset form" name="formReset" />
</form>

<p><b>Infos zur Dateneingabe</b></p>

<ul>
<li><b>Zwei Eingabephasen:</b> Die Eingabe eines neuen Titels erfolgt
in zwei Phasen (stages). In der ersten Phase reicht es bei den
Autoren- und Verlagsnamen aus, nur einige Anfangsbuchstaben
anzugeben. Bei Autorennamen m�ssen die Anfangsbuchstaben des Nachnamen
angegeben werden (also (z.B. <i>kof</i> statt <i>Michael
Kofler</i>). Falls Autoren/Verlage mit diesen Anfangsbuchstaben in der
Datenbank gefunden werden, k�nnen Sie diese in der zweiten Phase
bequem durch einen Mausklick ausw�hlen. Andernfalls haben Sie auch in
der zweiten Phase noch Gelegenheit, den vollst�ndigen Namen anzugeben.</li>

<li><p><b>Autoren:</b> <b>Der Nachname (Familienname) muss am Ende
angegeben werden, also z.B. <i>Stephen King</i>!</b> In der ersten
Eingabephase d�rfen auch mehrere Autoren angegeben werden, die durch
Kommas oder Strichpunkte voneinander getrennt werden, z.B.: <i>Stephen
King, Joanne K. Rowling</i></p></li>

<li><p><b>Erforderliche Daten:</b> Es m�ssen nur die mit einem Stern *
markierten Eingabefelder ausgef�llt werden.</p></li>
</ul>

<form method="post" action="input.php">
<input type="submit" value="Reset form" name="formReset" />
</form>


<?php show_copyright(); ?>

</body></html>
