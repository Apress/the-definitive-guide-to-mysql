/* Hellow.java */

public class Hellow
{
  public static void main(String[] args)
  {
    System.out.println("Hello, world!");
  }
}

