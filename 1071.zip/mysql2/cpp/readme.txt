Diese Beispiele geh�ren zum Buch

  Michael Kofler: MySQL, 2. Auflage
  deutsche Ausgabe: Addison-Wesley Germany

Diese Beispielprogramme wurden unter SuSE Linux 8.1/8.2 mit gcc 3.2 getestet. Sie m�ssen Benutzername und Passwort �ndern, damit die Beispiele laufen.

Weitere Details finden Sie in Kapitel 16.

----------------

Theses samples are part of the book

  Michael Kofler: MySQL
  english edition: apress, 2nd edition

These samples have been tested with SuSE Linux 8.1/8.2 and gcc 3.2. You must change the username and password strings! 

For further details see chapter 16.

---------------

(c) 2001, 2002, 2003 Michael Kofler
