<?php // file myforum/forumread.php     -*- C++ -*- 

// show subject list for a forum
// url parameters: forumID, page

// include some standard functions
include("myforumconnect.inc.php");

// read URL variables
$forumID = array_item($_REQUEST, 'forumID');
$page    = array_item($_REQUEST, 'page');

// session management
session_start();
if(empty($_SESSION['sesUserID'])) {
  $_SESSION['sesUserName'] = "anonymous";
}
if(SID) {
  $sid1 = "?" . SID;
  $sid2 = "&" . SID; }
else {
  $sid1=""; $sid2=""; }

// connect to database
$connID = connect_to_myforum();

// is $forumID empty? --> goto forumlist.php
if(empty($forumID)) {
  header("Location: forumlist.php$sid1");
  exit;
}

// main code starts here ------------------------------

?>
<!-- start of html document if no connection error has happened -->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html><head>
  <meta http-equiv="Content-Type" 
        content="text/html; charset=iso-8859-1" />
  <title>PHP Programming, browse discussion group (myforum database)</title>
</head><body>
<h2>Browse discussion group</h2>

<?php

echo "<p>Username: ", htmlentities($_SESSION['sesUserName']), "</p>\n";

// test if forumID is valid
$forumID = trim($forumID);
$result = mysql_query("SELECT forumName, language FROM forums " .
                      "WHERE forumID='$forumID' LIMIT 2");
if(!$result or mysql_num_rows($result)!=1) {
  echo '<p><font color="#ff0000">ID number of forum seems ', 
    "to be invalid.</font> Please choose a forum in the ",
    "<a href=\"forumlist.php$sid1\">forum list</a>.</p>\n";
  show_copyright(); 
  echo "</body></html>\n";
  exit;
}

// show list name
$row = mysql_fetch_object($result);
echo "<h3>Forum ", htmlentities($row->forumName), 
  " (", htmlentities($row->language),  ")</h3>\n";
mysql_free_result($result);

// page management
$pagesize = 50;
if(!$page or !(is_numeric($page)) or $page<0 or $page>100)
  $page=1;

// show all messages for one page
// use temporary table for msgIDs to get n last messages
mysql_query("DROP TABLE IF EXISTS tmpMsgIDs");
mysql_query("CREATE TEMPORARY TABLE tmpMsgIDs TYPE = HEAP " .
            "SELECT msgID FROM messages " .
            "WHERE forumID = $forumID " .
            "ORDER BY timest DESC " .
            "LIMIT " . ($pagesize*($page-1)) . ", " . ($pagesize+1));
if(mysql_affected_rows() > $pagesize)
  $moremessages=1;
else
  $moremessages=0;

// second query to get full data
$result = 
  mysql_query("SELECT messages.msgID, subject, level, rootID, " .
              "       DATE_FORMAT(messages.timest, '%Y/%c/%e %k:%i') " .
              "         AS timest, " .
              "       username " .
              "FROM messages, users, tmpMsgIDs " .
              "WHERE messages.msgID = tmpMsgIDs.msgID " .
              "  AND messages.userID = users.userID " .
              "ORDER BY LEFT(orderstr, 4) DESC, orderstr");

// drop temporary table
mysql_query("DROP TABLE tmpMsgIDs");

// show subjects, names and date/time
$oldthreadID = 0;
$threadCounter = 0;
if(mysql_num_rows($result)) {
  echo '<table border="0" cellpadding="5" cellspacing="0">', "\n";
  while($row=mysql_fetch_object($result)) {
    // change background color with beginning of each new thread
    if($row->rootID!=$oldthreadID) $threadCounter++;
    if($threadCounter % 2)
      $color = '"#eeeeee"';
    else
      $color = '"#dddddd"';
    // show beginning of new thread
    if($row->rootID!=0 and $row->rootID!=$oldthreadID) {
      $query = "rootID=$row->rootID" . $sid2;
      echo "<tr bgcolor=$color><td>", 
        build_href("forumthread.php", $query, "(show entire thread)"),
        "</td><td></td><td></td>\n";
    }
    // show subject, name and date
    $query = "msgID=$row->msgID" . $sid2;
    $shortSubj = substr($row->subject, 0, 55);
    if(strlen($row->subject)>55)
      $shortSubj .= " ...";
    echo "<tr bgcolor=$color><td>", 
      $row->level ? str_repeat("&nbsp;&nbsp;&nbsp;", $row->level) : "",
      build_href("forummessage.php", $query, $shortSubj), "</td>",
      "<td align=\"center\"><i>", htmlentities($row->username), "</i>", "</td>",
      "<td align=\"right\"> $row->timest </td>\n";
    // update oldthreadID
    if($row->rootID==0)
      $oldthreadID=$row->msgID;
    else
      $oldthreadID=$row->rootID;
  }
  echo "</table>\n";
}

// show links to older/newer messages
echo "<p><hr />\n";
if($page>1) {
  $query = "forumID=$forumID&page=" . ($page-1) . $sid2;
  echo build_href("forumread.php", $query, "Show newer messages.");
  if($moremessages) echo " / ";
}
if($moremessages) {
  $query = "forumID=$forumID&page=" . ($page+1) . $sid2;
  echo build_href("forumread.php", $query, "Show older messages.");
}
echo "</p>\n";

// show link to write a new message
if($page>1 or $moremessages)
  echo " / ";
$query = "forumID=$forumID" . $sid2;
echo build_href("forumwrite.php", $query, "Write a new message"), 
  ".\n";


// show link to group list
echo "<p>", build_href("forumlist.php", SID, "List of all forums"), ".</p>\n";

// show link to logout 
echo "<br />", build_href("forumlogout.php", "", "Logout"), ".</p>\n";

// show copyright message for all examples
show_copyright(); 

?>

</body></html>
