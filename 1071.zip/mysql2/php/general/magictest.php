<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN"> <!-- -*- C++ -*-  -->
<!-- file general/magictest.php    -->
<html><head>
<meta http-equiv="Content-Type" 
      content="text/html; charset=iso-8859-1" />
<title>PHP Programming, magic test</title>
</head><body>

<?php {

  function array_item($ar, $key) {
    if(array_key_exists($key, $ar))
      return($ar[$key]); }

  function no_magic() {  // needs PHP >= 4.1
    if (get_magic_quotes_gpc()) {
      foreach($_GET as $k=>$v)    $_GET["$k"] = stripslashes($v);
      foreach($_POST as $k=>$v)   $_POST["$k"] = stripslashes($v);
      foreach($_COOKIE as $k=>$v) $_COOKIE["$k"] = stripslashes($v);
    }
  }

  // show magic_quotes_gpc status
  echo "<p>get_magic_quotes_gpc = ", get_magic_quotes_gpc(), "</p>\n";

  // copy form input into variables
  $submitbutton = array_item($_POST, 'submitbutton');
  $name1 = array_item($_POST, 'name1');
  $name2 = array_item($_POST, 'name2');

  // is form data here?
  if($submitbutton == "OK") {
    // show data
    echo "<h2>Before no_magic()</h2>\n";
    echo "<p>name1 =  ", $name1, "\n";
    echo "<br />name2 =  ", $name2, "</p>\n";
    echo "<p>htmlentities(name1) =  ", htmlentities($name1), "\n";
    echo "<br />htmlentities(name2) =  ", htmlentities($name2), "</p>\n\n";

    // remove magic slashes, show data again
    no_magic();
    echo "<h2>After no_magic()</h2>\n";
    $name1 = array_item($_POST, 'name1');
    $name2 = array_item($_POST, 'name2');
    echo "<p>name1 =  ", $name1, "\n";
    echo "<br />name2 =  ", $name2, "</p>\n";
    echo "<p>htmlentities(name1) =  ", htmlentities($name1), "\n";
    echo "<br />htmlentities(name2) =  ", htmlentities($name2), "</p>\n";
  }
} ?>

<h2>Test form</h2>

<form method="POST" action="magictest.php">
<p><input type="text" name="name1" size="30" maxlength="30" 
    value="<?php echo htmlspecialchars($name1); ?>" /></p>
<p><input type="text" name="name2" size="30" maxlength="30" 
    value="<?php echo htmlspecialchars($name2); ?>" /></p>
<p><input type="submit" name="submitbutton" value="OK" /></p>
</form>

</body></html>
