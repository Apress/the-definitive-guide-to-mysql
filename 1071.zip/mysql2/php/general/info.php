<?php  // file general/info.php     -*- C++ -*- 
  include("mylibraryconnect.inc.php");
  $connID = connect_to_mylibrary();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html><head>
<meta http-equiv="Content-Type" 
      content="text/html; charset=iso-8859-1" />
<title>PHP Programming, connection and server infos</title>
</head><body>

<?php 

echo "<p>Client encoding: " . mysql_client_encoding() . "</p>\n";

echo "<p>Client info: " . mysql_get_client_info() . "</p>\n";

echo "<p>Host info: " . mysql_get_host_info() . "</p>\n";

echo "<p>Server info: " . mysql_get_server_info() . "</p>\n";

echo "<p>Protocol info: " . mysql_get_proto_info() . "</p>\n";

echo "<p>Thread ID: " . mysql_thread_id() . "</p>\n";

echo "<p>Status: " . mysql_stat() . "</p>\n";

mysql_query("SELECT * FROM publishers");

echo "<p>Info: " . mysql_info() . "</p>\n";


show_copyright();   // defined in mylibraryconnect.inc.php

?>
</body></html>
