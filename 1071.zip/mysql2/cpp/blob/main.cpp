#include <iostream>
#include <fstream>
#include <sqlplus.hh>

using namespace std;

int main(int argc, char *argv[])
{
  Connection conn(use_exceptions);
  try {
    // connect to MySQL server
    conn.connect("exceptions", "localhost", "root", "uranus");   

    // load file first into *char and then into string buffer
    ifstream infile("test.jpg", ios::in | ios::binary | ios::ate);
    long size = infile.tellg();
    char *buffer = new char[size];
    infile.seekg(0, ios::beg);     // read from beginning
    infile.read(buffer, size);     // from file to *char
    string sbuffer(buffer, size);  // from *char to string
    infile.close();

    // save binary data in database
    ostrstream strbuf1;
    strbuf1 << "INSERT INTO test_blob (a_blob) VALUES ('"
	    << escape << sbuffer << "')" << ends;
    conn.exec(strbuf1.str());

    // retrieve binary data from database
    int id = conn.insert_id();     // AUTO_INCREMENT id of prev. saved data
    Query  query = conn.query();
    query << "SELECT a_blob FROM test_blob WHERE id=" << id;
    Result result = query.store();
    Row row = result.fetch_row();
    unsigned long *lengths;
    lengths = result.fetch_lengths();
    
    // save binary data into new file
    ofstream outfile("test-copy.jpg", ios::out | ios::binary);
    outfile.write(row.raw_data(0), lengths[0]);
    outfile.close();

    // close Result object, delete new recordset
    result.purge();
    ostrstream strbuf2;
    strbuf2 << "DELETE FROM test_blob WHERE id=" << id << ends;
    conn.exec(strbuf2.str());

    // close objects, free memory
    conn.close();
    return 0;

  } // handle connect and query exceptions
    catch(BadQuery er) {
    cerr << "connection or query exception: " << er.error << endl;
    return 1; 
  }
}
