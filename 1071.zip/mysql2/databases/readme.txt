Diese Beispiele geh�ren zum Buch

  Michael Kofler: MySQL, 2. Auflage
  deutsche Ausgabe: Addison-Wesley Germany

Um die Datenbanken zu installieren, f�hren Sie f�r jede Datenbankdatei die folgenden Kommandos aus:

mysqladmin -u yourusername -p create databasename
mysql -u yourusername -p databasename < databasename.sql

Weitere Details finden Sie in Anhang C.

----------------

Theses samples are part of the book

  Michael Kofler: MySQL
  english edition: apress, 2nd edition

To install the databases, execute these commands:

mysqladmin -u yourusername -p create databasename
mysql -u yourusername -p databasename < databasename.sql

For further details see appendix C.

---------------

(c) 2001, 2002, 2003 Michael Kofler
