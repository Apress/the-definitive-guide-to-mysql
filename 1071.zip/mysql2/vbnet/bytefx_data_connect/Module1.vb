Option Strict On
Imports ByteFX.Data.MySQLClient

Module Module1
  Dim myconn As MySQLConnection

  Sub Main()
    myconn = New MySQLConnection( _
      "Data Source=localhost;Initial Catalog=mylibraryodbc;" + _
      "User ID=root;Password=saturn;Use Compression=true")
    myconn.Open()
    Console.WriteLine("Compression: {0}", myconn.UseCompression)
    read_publishers_datareader()
    ' read_publishers_dataset()
    myconn.Close()
    Console.WriteLine("Return dr�cken")
    Console.ReadLine()
  End Sub

  ' sample for OdbcDataReader
  Sub read_publishers_datareader()
    Dim com As MySQLCommand
    Dim dr As MySQLDataReader
    com = New MySQLCommand( _
      "SELECT publID, publName FROM publishers ORDER BY publName", myconn)
    dr = com.ExecuteReader()
    While dr.Read()
      Console.WriteLine("id: {0} name: {1}", dr!publID, dr!publName)
    End While
    dr.Close()
  End Sub

  ' sample for Dataset
  Sub read_publishers_dataset()
    Dim da As MySQLDataAdapter
    Dim ds As DataSet
    Dim row As DataRow
    Dim dt As DataTable

    Try
      ds = New DataSet()
      da = New MySQLDataAdapter( _
        "SELECT publID, publName FROM publishers ORDER BY publName", myconn)
      da.Fill(ds)
      dt = ds.Tables(0)
      For Each row In dt.Rows
        Console.WriteLine("id: {0} name: {1}", row!publID, row!publName)
      Next
      ds.Dispose()
      da.Dispose()
    Catch e As MySQLException
      MsgBox(e.Message)
    End Try
  End Sub

  
End Module


