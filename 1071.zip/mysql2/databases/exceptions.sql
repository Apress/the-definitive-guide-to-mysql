-- MySQL dump 9.07
--
-- Host: localhost    Database: exceptions
---------------------------------------------------------
-- Server version	4.0.12-nt-log

--
-- Table structure for table 'access_test'
--

CREATE TABLE access_test (
  id int(11) NOT NULL auto_increment,
  ts timestamp(14) NOT NULL,
  a_double double default '0',
  a_long_text longtext,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'access_test'
--

INSERT INTO access_test VALUES (1,20030219102138,1,'abc');
INSERT INTO access_test VALUES (2,20030219102142,2,NULL);

--
-- Table structure for table 'exporttable'
--

CREATE TABLE exporttable (
  id int(11) NOT NULL default '0',
  a_char varchar(10) default NULL,
  a_text text,
  a_blob blob,
  a_date date default '0000-00-00',
  a_time time default '00:00:00',
  a_timestamp timestamp(14) NOT NULL,
  a_float float default '0',
  a_decimal decimal(10,3) default '0.000',
  a_enum enum('a','b','c') default 'a',
  a_set set('e','f','g') default NULL
) TYPE=MyISAM;

--
-- Dumping data for table 'exporttable'
--

INSERT INTO exporttable VALUES (1,'char char','text text','blob blob','2001-12-31','12:30:00',20001117164643,3.14159,0.012,'b','e,g');
INSERT INTO exporttable VALUES (2,'\' \" \\ ; +','adsf',NULL,'2000-11-17','16:54:54',20001117165454,-2.3e-037,12.345,'a','f,g');

--
-- Table structure for table 'importtable1'
--

CREATE TABLE importtable1 (
  id int(11) NOT NULL auto_increment,
  a_number double default '0',
  a_date datetime default '0000-00-00 00:00:00',
  a_time time default '00:00:00',
  a_string text,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'importtable1'
--

INSERT INTO importtable1 VALUES (1,31.12,'0000-00-00 00:00:00','00:00:00',NULL);
INSERT INTO importtable1 VALUES (2,-0.0033,'2000-12-31 00:00:00','11:20:00','text in quotes');
INSERT INTO importtable1 VALUES (3,1,'2031-12-20 01:00:00','00:13:00','german text with ����');
INSERT INTO importtable1 VALUES (14,2000,'0000-00-00 00:00:00','00:00:00',NULL);
INSERT INTO importtable1 VALUES (13,2000,'0000-00-00 00:00:00','00:00:00',NULL);
INSERT INTO importtable1 VALUES (12,12,'0000-00-00 00:00:00','00:00:00',NULL);

--
-- Table structure for table 'importtable2'
--

CREATE TABLE importtable2 (
  id int(11) NOT NULL auto_increment,
  a_blob blob,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'importtable2'
--

INSERT INTO importtable2 VALUES (1,NULL);
INSERT INTO importtable2 VALUES (2,'NULL');
INSERT INTO importtable2 VALUES (3,NULL);
INSERT INTO importtable2 VALUES (4,NULL);
INSERT INTO importtable2 VALUES (5,'\n');
INSERT INTO importtable2 VALUES (6,'\n');
INSERT INTO importtable2 VALUES (7,'0x414243');
INSERT INTO importtable2 VALUES (8,NULL);
INSERT INTO importtable2 VALUES (9,'blob blob');
INSERT INTO importtable2 VALUES (10,'blob blob');

--
-- Table structure for table 'test_blob'
--

CREATE TABLE test_blob (
  id int(11) NOT NULL auto_increment,
  a_blob blob,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'test_blob'
--

INSERT INTO test_blob VALUES (1,'\0	\n\r\Z !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~��������������������������������������������������������������������������������������������������������������������������������\0	\n\r\Z !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~��������������������������������������������������������������������������������������������������������������������������������');

--
-- Table structure for table 'test_date'
--

CREATE TABLE test_date (
  id int(11) NOT NULL auto_increment,
  a_date date default NULL,
  a_time time default NULL,
  a_datetime datetime default NULL,
  a_timestamp timestamp(14) NOT NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'test_date'
--

INSERT INTO test_date VALUES (1,'2000-12-07','09:06:29','2000-12-07 09:06:29',20001207090649);
INSERT INTO test_date VALUES (22,'0000-00-00',NULL,NULL,20010115091853);
INSERT INTO test_date VALUES (21,'0000-00-00',NULL,NULL,20010115091841);
INSERT INTO test_date VALUES (20,'2001-02-29',NULL,NULL,20010115091644);
INSERT INTO test_date VALUES (19,'0000-00-00',NULL,NULL,20010115091616);

--
-- Table structure for table 'test_enum'
--

CREATE TABLE test_enum (
  id int(11) NOT NULL auto_increment,
  a_enum enum('a','b','c','d','e') default NULL,
  a_set set('a','b','c','d','e') default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'test_enum'
--

INSERT INTO test_enum VALUES (1,'a','a');
INSERT INTO test_enum VALUES (2,'e','b,c,d');
INSERT INTO test_enum VALUES (4,NULL,NULL);

--
-- Table structure for table 'test_null'
--

CREATE TABLE test_null (
  id int(11) NOT NULL auto_increment,
  a_text text,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'test_null'
--

INSERT INTO test_null VALUES (1,NULL);
INSERT INTO test_null VALUES (2,'');
INSERT INTO test_null VALUES (3,'a text');
INSERT INTO test_null VALUES (4,'?');

--
-- Table structure for table 'test_odbc'
--

CREATE TABLE test_odbc (
  id bigint(20) NOT NULL auto_increment,
  data int(11) NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'test_odbc'
--

INSERT INTO test_odbc VALUES (1,2311);
INSERT INTO test_odbc VALUES (2,235);
INSERT INTO test_odbc VALUES (3,46);
INSERT INTO test_odbc VALUES (4,235);

--
-- Table structure for table 'test_order_by'
--

CREATE TABLE test_order_by (
  id int(11) NOT NULL auto_increment,
  a_char char(1) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'test_order_by'
--

INSERT INTO test_order_by VALUES (1,'');
INSERT INTO test_order_by VALUES (2,'');
INSERT INTO test_order_by VALUES (3,'');
INSERT INTO test_order_by VALUES (4,'');
INSERT INTO test_order_by VALUES (5,'');
INSERT INTO test_order_by VALUES (6,'');
INSERT INTO test_order_by VALUES (7,'');
INSERT INTO test_order_by VALUES (8,'');
INSERT INTO test_order_by VALUES (9,'	');
INSERT INTO test_order_by VALUES (10,'\n');
INSERT INTO test_order_by VALUES (11,'');
INSERT INTO test_order_by VALUES (12,'');
INSERT INTO test_order_by VALUES (13,'\r');
INSERT INTO test_order_by VALUES (14,'');
INSERT INTO test_order_by VALUES (15,'');
INSERT INTO test_order_by VALUES (16,'');
INSERT INTO test_order_by VALUES (17,'');
INSERT INTO test_order_by VALUES (18,'');
INSERT INTO test_order_by VALUES (19,'');
INSERT INTO test_order_by VALUES (20,'');
INSERT INTO test_order_by VALUES (21,'');
INSERT INTO test_order_by VALUES (22,'');
INSERT INTO test_order_by VALUES (23,'');
INSERT INTO test_order_by VALUES (24,'');
INSERT INTO test_order_by VALUES (25,'');
INSERT INTO test_order_by VALUES (26,'\Z');
INSERT INTO test_order_by VALUES (27,'');
INSERT INTO test_order_by VALUES (28,'');
INSERT INTO test_order_by VALUES (29,'');
INSERT INTO test_order_by VALUES (30,'');
INSERT INTO test_order_by VALUES (31,'');
INSERT INTO test_order_by VALUES (32,'');
INSERT INTO test_order_by VALUES (33,'!');
INSERT INTO test_order_by VALUES (34,'\"');
INSERT INTO test_order_by VALUES (35,'#');
INSERT INTO test_order_by VALUES (36,'$');
INSERT INTO test_order_by VALUES (37,'%');
INSERT INTO test_order_by VALUES (38,'&');
INSERT INTO test_order_by VALUES (39,'\'');
INSERT INTO test_order_by VALUES (40,'(');
INSERT INTO test_order_by VALUES (41,')');
INSERT INTO test_order_by VALUES (42,'*');
INSERT INTO test_order_by VALUES (43,'+');
INSERT INTO test_order_by VALUES (44,',');
INSERT INTO test_order_by VALUES (45,'-');
INSERT INTO test_order_by VALUES (46,'.');
INSERT INTO test_order_by VALUES (47,'/');
INSERT INTO test_order_by VALUES (48,'0');
INSERT INTO test_order_by VALUES (49,'1');
INSERT INTO test_order_by VALUES (50,'2');
INSERT INTO test_order_by VALUES (51,'3');
INSERT INTO test_order_by VALUES (52,'4');
INSERT INTO test_order_by VALUES (53,'5');
INSERT INTO test_order_by VALUES (54,'6');
INSERT INTO test_order_by VALUES (55,'7');
INSERT INTO test_order_by VALUES (56,'8');
INSERT INTO test_order_by VALUES (57,'9');
INSERT INTO test_order_by VALUES (58,':');
INSERT INTO test_order_by VALUES (59,';');
INSERT INTO test_order_by VALUES (60,'<');
INSERT INTO test_order_by VALUES (61,'=');
INSERT INTO test_order_by VALUES (62,'>');
INSERT INTO test_order_by VALUES (63,'?');
INSERT INTO test_order_by VALUES (64,'@');
INSERT INTO test_order_by VALUES (65,'A');
INSERT INTO test_order_by VALUES (66,'B');
INSERT INTO test_order_by VALUES (67,'C');
INSERT INTO test_order_by VALUES (68,'D');
INSERT INTO test_order_by VALUES (69,'E');
INSERT INTO test_order_by VALUES (70,'F');
INSERT INTO test_order_by VALUES (71,'G');
INSERT INTO test_order_by VALUES (72,'H');
INSERT INTO test_order_by VALUES (73,'I');
INSERT INTO test_order_by VALUES (74,'J');
INSERT INTO test_order_by VALUES (75,'K');
INSERT INTO test_order_by VALUES (76,'L');
INSERT INTO test_order_by VALUES (77,'M');
INSERT INTO test_order_by VALUES (78,'N');
INSERT INTO test_order_by VALUES (79,'O');
INSERT INTO test_order_by VALUES (80,'P');
INSERT INTO test_order_by VALUES (81,'Q');
INSERT INTO test_order_by VALUES (82,'R');
INSERT INTO test_order_by VALUES (83,'S');
INSERT INTO test_order_by VALUES (84,'T');
INSERT INTO test_order_by VALUES (85,'U');
INSERT INTO test_order_by VALUES (86,'V');
INSERT INTO test_order_by VALUES (87,'W');
INSERT INTO test_order_by VALUES (88,'X');
INSERT INTO test_order_by VALUES (89,'Y');
INSERT INTO test_order_by VALUES (90,'Z');
INSERT INTO test_order_by VALUES (91,'[');
INSERT INTO test_order_by VALUES (92,'\\');
INSERT INTO test_order_by VALUES (93,']');
INSERT INTO test_order_by VALUES (94,'^');
INSERT INTO test_order_by VALUES (95,'_');
INSERT INTO test_order_by VALUES (96,'`');
INSERT INTO test_order_by VALUES (97,'a');
INSERT INTO test_order_by VALUES (98,'b');
INSERT INTO test_order_by VALUES (99,'c');
INSERT INTO test_order_by VALUES (100,'d');
INSERT INTO test_order_by VALUES (101,'e');
INSERT INTO test_order_by VALUES (102,'f');
INSERT INTO test_order_by VALUES (103,'g');
INSERT INTO test_order_by VALUES (104,'h');
INSERT INTO test_order_by VALUES (105,'i');
INSERT INTO test_order_by VALUES (106,'j');
INSERT INTO test_order_by VALUES (107,'k');
INSERT INTO test_order_by VALUES (108,'l');
INSERT INTO test_order_by VALUES (109,'m');
INSERT INTO test_order_by VALUES (110,'n');
INSERT INTO test_order_by VALUES (111,'o');
INSERT INTO test_order_by VALUES (112,'p');
INSERT INTO test_order_by VALUES (113,'q');
INSERT INTO test_order_by VALUES (114,'r');
INSERT INTO test_order_by VALUES (115,'s');
INSERT INTO test_order_by VALUES (116,'t');
INSERT INTO test_order_by VALUES (117,'u');
INSERT INTO test_order_by VALUES (118,'v');
INSERT INTO test_order_by VALUES (119,'w');
INSERT INTO test_order_by VALUES (120,'x');
INSERT INTO test_order_by VALUES (121,'y');
INSERT INTO test_order_by VALUES (122,'z');
INSERT INTO test_order_by VALUES (123,'{');
INSERT INTO test_order_by VALUES (124,'|');
INSERT INTO test_order_by VALUES (125,'}');
INSERT INTO test_order_by VALUES (126,'~');
INSERT INTO test_order_by VALUES (127,'');
INSERT INTO test_order_by VALUES (128,'�');
INSERT INTO test_order_by VALUES (129,'�');
INSERT INTO test_order_by VALUES (130,'�');
INSERT INTO test_order_by VALUES (131,'�');
INSERT INTO test_order_by VALUES (132,'�');
INSERT INTO test_order_by VALUES (133,'�');
INSERT INTO test_order_by VALUES (134,'�');
INSERT INTO test_order_by VALUES (135,'�');
INSERT INTO test_order_by VALUES (136,'�');
INSERT INTO test_order_by VALUES (137,'�');
INSERT INTO test_order_by VALUES (138,'�');
INSERT INTO test_order_by VALUES (139,'�');
INSERT INTO test_order_by VALUES (140,'�');
INSERT INTO test_order_by VALUES (141,'�');
INSERT INTO test_order_by VALUES (142,'�');
INSERT INTO test_order_by VALUES (143,'�');
INSERT INTO test_order_by VALUES (144,'�');
INSERT INTO test_order_by VALUES (145,'�');
INSERT INTO test_order_by VALUES (146,'�');
INSERT INTO test_order_by VALUES (147,'�');
INSERT INTO test_order_by VALUES (148,'�');
INSERT INTO test_order_by VALUES (149,'�');
INSERT INTO test_order_by VALUES (150,'�');
INSERT INTO test_order_by VALUES (151,'�');
INSERT INTO test_order_by VALUES (152,'�');
INSERT INTO test_order_by VALUES (153,'�');
INSERT INTO test_order_by VALUES (154,'�');
INSERT INTO test_order_by VALUES (155,'�');
INSERT INTO test_order_by VALUES (156,'�');
INSERT INTO test_order_by VALUES (157,'�');
INSERT INTO test_order_by VALUES (158,'�');
INSERT INTO test_order_by VALUES (159,'�');
INSERT INTO test_order_by VALUES (160,'�');
INSERT INTO test_order_by VALUES (161,'�');
INSERT INTO test_order_by VALUES (162,'�');
INSERT INTO test_order_by VALUES (163,'�');
INSERT INTO test_order_by VALUES (164,'�');
INSERT INTO test_order_by VALUES (165,'�');
INSERT INTO test_order_by VALUES (166,'�');
INSERT INTO test_order_by VALUES (167,'�');
INSERT INTO test_order_by VALUES (168,'�');
INSERT INTO test_order_by VALUES (169,'�');
INSERT INTO test_order_by VALUES (170,'�');
INSERT INTO test_order_by VALUES (171,'�');
INSERT INTO test_order_by VALUES (172,'�');
INSERT INTO test_order_by VALUES (173,'�');
INSERT INTO test_order_by VALUES (174,'�');
INSERT INTO test_order_by VALUES (175,'�');
INSERT INTO test_order_by VALUES (176,'�');
INSERT INTO test_order_by VALUES (177,'�');
INSERT INTO test_order_by VALUES (178,'�');
INSERT INTO test_order_by VALUES (179,'�');
INSERT INTO test_order_by VALUES (180,'�');
INSERT INTO test_order_by VALUES (181,'�');
INSERT INTO test_order_by VALUES (182,'�');
INSERT INTO test_order_by VALUES (183,'�');
INSERT INTO test_order_by VALUES (184,'�');
INSERT INTO test_order_by VALUES (185,'�');
INSERT INTO test_order_by VALUES (186,'�');
INSERT INTO test_order_by VALUES (187,'�');
INSERT INTO test_order_by VALUES (188,'�');
INSERT INTO test_order_by VALUES (189,'�');
INSERT INTO test_order_by VALUES (190,'�');
INSERT INTO test_order_by VALUES (191,'�');
INSERT INTO test_order_by VALUES (192,'�');
INSERT INTO test_order_by VALUES (193,'�');
INSERT INTO test_order_by VALUES (194,'�');
INSERT INTO test_order_by VALUES (195,'�');
INSERT INTO test_order_by VALUES (196,'�');
INSERT INTO test_order_by VALUES (197,'�');
INSERT INTO test_order_by VALUES (198,'�');
INSERT INTO test_order_by VALUES (199,'�');
INSERT INTO test_order_by VALUES (200,'�');
INSERT INTO test_order_by VALUES (201,'�');
INSERT INTO test_order_by VALUES (202,'�');
INSERT INTO test_order_by VALUES (203,'�');
INSERT INTO test_order_by VALUES (204,'�');
INSERT INTO test_order_by VALUES (205,'�');
INSERT INTO test_order_by VALUES (206,'�');
INSERT INTO test_order_by VALUES (207,'�');
INSERT INTO test_order_by VALUES (208,'�');
INSERT INTO test_order_by VALUES (209,'�');
INSERT INTO test_order_by VALUES (210,'�');
INSERT INTO test_order_by VALUES (211,'�');
INSERT INTO test_order_by VALUES (212,'�');
INSERT INTO test_order_by VALUES (213,'�');
INSERT INTO test_order_by VALUES (214,'�');
INSERT INTO test_order_by VALUES (215,'�');
INSERT INTO test_order_by VALUES (216,'�');
INSERT INTO test_order_by VALUES (217,'�');
INSERT INTO test_order_by VALUES (218,'�');
INSERT INTO test_order_by VALUES (219,'�');
INSERT INTO test_order_by VALUES (220,'�');
INSERT INTO test_order_by VALUES (221,'�');
INSERT INTO test_order_by VALUES (222,'�');
INSERT INTO test_order_by VALUES (223,'�');
INSERT INTO test_order_by VALUES (224,'�');
INSERT INTO test_order_by VALUES (225,'�');
INSERT INTO test_order_by VALUES (226,'�');
INSERT INTO test_order_by VALUES (227,'�');
INSERT INTO test_order_by VALUES (228,'�');
INSERT INTO test_order_by VALUES (229,'�');
INSERT INTO test_order_by VALUES (230,'�');
INSERT INTO test_order_by VALUES (231,'�');
INSERT INTO test_order_by VALUES (232,'�');
INSERT INTO test_order_by VALUES (233,'�');
INSERT INTO test_order_by VALUES (234,'�');
INSERT INTO test_order_by VALUES (235,'�');
INSERT INTO test_order_by VALUES (236,'�');
INSERT INTO test_order_by VALUES (237,'�');
INSERT INTO test_order_by VALUES (238,'�');
INSERT INTO test_order_by VALUES (239,'�');
INSERT INTO test_order_by VALUES (240,'�');
INSERT INTO test_order_by VALUES (241,'�');
INSERT INTO test_order_by VALUES (242,'�');
INSERT INTO test_order_by VALUES (243,'�');
INSERT INTO test_order_by VALUES (244,'�');
INSERT INTO test_order_by VALUES (245,'�');
INSERT INTO test_order_by VALUES (246,'�');
INSERT INTO test_order_by VALUES (247,'�');
INSERT INTO test_order_by VALUES (248,'�');
INSERT INTO test_order_by VALUES (249,'�');
INSERT INTO test_order_by VALUES (250,'�');
INSERT INTO test_order_by VALUES (251,'�');
INSERT INTO test_order_by VALUES (252,'�');
INSERT INTO test_order_by VALUES (253,'�');
INSERT INTO test_order_by VALUES (254,'�');
INSERT INTO test_order_by VALUES (255,'�');

--
-- Table structure for table 'testall'
--

CREATE TABLE testall (
  id int(11) NOT NULL auto_increment,
  a_big_int bigint(20) default '0',
  a_char varchar(10) default NULL,
  a_text text,
  a_blob blob,
  a_date date default '0000-00-00',
  a_time time default '00:00:00',
  a_timestamp timestamp(14) NOT NULL,
  a_float float default '0',
  a_decimal decimal(10,3) default '0.000',
  a_enum enum('a','b','c') default 'a',
  a_set set('e','f','g') default NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'testall'
--

INSERT INTO testall VALUES (1,0,'char char','text text','blob blob','2001-12-31','12:30:00',20001117164643,3.14159,0.012,'b','e,g');
INSERT INTO testall VALUES (2,0,'\' \" \\ ; +','adsf',NULL,'2000-11-17','16:54:54',20001117165454,-2.3e-037,12.345,'a','f,g');
INSERT INTO testall VALUES (3,0,NULL,NULL,NULL,NULL,'00:00:00',20030214081103,0,0.000,'a',NULL);
INSERT INTO testall VALUES (4,1234567890123456,NULL,NULL,NULL,NULL,'00:00:00',20030214101201,0,0.000,'a',NULL);
INSERT INTO testall VALUES (10,123,NULL,NULL,NULL,'0000-00-00','00:00:00',20030214102925,0,0.000,'a',NULL);

