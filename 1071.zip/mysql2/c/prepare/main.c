#include <stdio.h>
#include <mysql.h>

int main(int argc, char *argv[])
{
  MYSQL *conn;        // connection to MySQL server
  MYSQL_STMT *stmt;   // prepared statement
  MYSQL_BIND bind[3]; // parameters

  char *insert = 
    "INSERT INTO titles (title, subtitle, langID) VALUES (?, ?, ?)";
  char titlebuf[256];
  char subtitlebuf[256];
  int langID;

  // connect to MySQL
  conn = mysql_init(NULL);
  mysql_options(conn, MYSQL_READ_DEFAULT_FILE, "");
  if(mysql_real_connect(
        conn, "uranus.sol", "root", "",
        "mylibrary", 0, NULL, 0) == NULL) {
      fprintf(stderr, "sorry, no database connection ...\n");
      return 1;
    }

  // prepare statement
  stmt = mysql_prepare(conn, insert, strlen(insert));
  bind[0].buffer_type = FIELD_TYPE_STRING;
  bind[0].buffer = titlebuf;
  bind[0].buffer_length = 256;

  bind[1].buffer_type = FIELD_TYPE_STRING;
  bind[1].buffer = subtitlebuf;
  bind[1].buffer_length = 256;

  bind[2].buffer_type = FIELD_TYPE_LONG;
  bind[2].buffer = (gptr) &langID;
  mysql_bind_param(stmt, bind);

  // execute 
  strcpy(titlebuf, "title1");
  strcpy(subtitlebuf, "subtitle1");
  langID=999;
  mysql_execute(stmt);

  // execute again
  strcpy(titlebuf, "title2");
  strcpy(subtitlebuf, "subtitle2");
  langID++;
  mysql_execute(stmt);

  // close connection
  mysql_close(conn);
  return 0;
}
