#!/usr/bin/perl
print "Hello world!\n";

print "Please hit Return to end the program!";
$wait_for_return = <STDIN>;
