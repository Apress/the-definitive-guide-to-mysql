Option Strict On
Imports CoreLab.MySql

Module Module1
  Dim myconn As MySqlConnection

  Sub Main()
    myconn = New MySqlConnection( _
      "Host=localhost;Database=mylibraryodbc;" + _
      "User=root;Password=saturn;Connection Timeout=30")
    myconn.Open()
    read_publishers_datareader()
    ' read_publishers_dataset()
    myconn.Close()
    Console.WriteLine("Return dr�cken")
    Console.ReadLine()
  End Sub

  ' sample for OdbcDataReader
  Sub read_publishers_datareader()
    Dim com As MySQLCommand
    Dim dr As MySQLDataReader
    com = New MySQLCommand( _
      "SELECT publID, publName FROM publishers ORDER BY publName", myconn)
    dr = com.ExecuteReader()
    While dr.Read()
      Console.WriteLine("id: {0} name: {1}", dr!publID, dr!publName)
    End While
    dr.Close()
  End Sub

  ' sample for Dataset
  Sub read_publishers_dataset()
    Dim da As MySQLDataAdapter
    Dim ds As DataSet
    Dim row As DataRow
    Dim dt As DataTable

    Try
      ds = New DataSet()
      da = New MySQLDataAdapter( _
        "SELECT publID, publName FROM publishers ORDER BY publName", myconn)
      da.Fill(ds)
      dt = ds.Tables(0)
      For Each row In dt.Rows
        Console.WriteLine("id: {0} name: {1}", row!publID, row!publName)
      Next
      ds.Dispose()
      da.Dispose()
    Catch e As MySQLException
      MsgBox(e.Message)
    End Try
  End Sub

End Module
