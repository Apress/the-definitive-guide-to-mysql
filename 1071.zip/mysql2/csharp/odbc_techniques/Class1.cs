using System;
using Microsoft.Data.Odbc;

namespace odbc_connect {
  class mainclass         {
    [STAThread]
    static void Main(string[] args) {
      Odbctest tst = new Odbctest();
      tst.ReadPublishersDataset();
      Console.WriteLine("Return dr�cken");
      Console.ReadLine();
    }
  }

  class Odbctest {
    OdbcConnection odbcconn;

    public Odbctest() {     // use constructor to connect
      odbcconn = new OdbcConnection(
        "Driver={MySQL ODBC 3.51 Driver};Server=localhost;" + 
        "Database=exceptions;UID=root;PWD=saturn;Options=3");
      odbcconn.Open();
    }

    public void ReadPublishersDataset() {
      byte[] bin = new byte[50];
      int i;
      for(i=0; i<50; i++)
        bin[i]=(byte)i;

      OdbcCommand com = new OdbcCommand();
      com.Connection = odbcconn;
      com.CommandText = 
        "INSERT INTO testall (a_date, a_text, a_blob) VALUES(?, ?, ?)";
      com.Parameters.Add("pdate", OdbcType.DateTime);
      com.Parameters.Add("ptext", OdbcType.Text);
      com.Parameters.Add("pblob", OdbcType.Binary);

      com.Parameters["pdate"].Value = DateTime.Now;
      com.Parameters["ptext"].Value = "O'Hara";
      com.Parameters["pblob"].Value = System.Text.Encoding.UTF8.GetBytes("���");
      com.ExecuteNonQuery();
    }
  }
}
