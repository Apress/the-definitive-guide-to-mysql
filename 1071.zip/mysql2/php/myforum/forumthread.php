<?php // file myforum/forumthread.php     -*- C++ -*- 

// show subject list for a thread
// url parameters: rootID

// include some standard functions
include("myforumconnect.inc.php");

// read URL variables
$rootID = array_item($_REQUEST, 'rootID');

// is $rootID empty? --> goto forumlist.php
if(empty($rootID)) {
  header("Location: forumlist.php$sid1");
  exit;
}

// session management
session_start();
header("Cache-control: private"); // IE 6 Fix. 
if(empty($_SESSION['sesUserID'])) {
  $_SESSION['sesUserName'] = "anonymous";
}
if(SID) {
  $sid1 = "?" . SID;
  $sid2 = "&" . SID; }
else {
  $sid1=""; $sid2=""; }

// connect to database
$connID = connect_to_myforum();

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html><head>
  <meta http-equiv="Content-Type" 
        content="text/html; charset=iso-8859-1" />
  <title>PHP Programming, show thread (myforum database)</title>
</head><body>
<h2>Show myforum thread</h2>

<?php // main code starts here ------------------------------

echo "<p>Username: ", htmlentities($_SESSION['sesUserName']), 
  "</p>\n";

// test if rootID is valid
$rootID = trim($rootID);
$result = mysql_query("SELECT msgID, rootID FROM messages " .
                      "WHERE msgID='$rootID' LIMIT 2");
if(!$result 
   or mysql_num_rows($result)!=1 
   or mysql_result($result, 0, 1)!=0) {
  echo '<p><font color="#ff0000">ID number of message seems ', 
    "to be invalid.</font> Please choose a forum in the ",
    "<a href=\"forumlist.php$sid1\">forum list</a>.</p>\n";
  show_copyright(); 
  echo "</body></html>\n";
  exit;
}

// get all messages of this thread
$result = 
  mysql_query("SELECT messages.msgID, subject, msgText, level, rootID, " .
              "       DATE_FORMAT(messages.timest, '%Y/%c/%e %k:%i') " .
              "         AS timest, " .
              "       username, forumName " .
              "FROM messages, users, forums " .
              "WHERE (messages.rootID = '$rootID' " .
              "       OR messages.msgID = '$rootID') " .
              "   AND messages.userID = users.userID " . 
              "   AND messages.forumID = forums.forumID " . 
              "ORDER BY orderstr");

// show list of subjects, names and date/time
if(mysql_num_rows($result)) {
  echo '<p><table cellpadding="5" bgcolor="#eeeeee">', "\n";
  while($row=mysql_fetch_object($result)) {
    // show subject
    echo "<tr><td>", 
      $row->level ? str_repeat("&nbsp;&nbsp;&nbsp;", $row->level) : "",
      build_href("#$row->msgID", "", $row->subject), "</td>",
      "<td align=\"center\"><i>", htmlentities($row->username), "</i></td>",
      "<td align=\"right\">$row->timest</td> \n";
  }
  echo "</table></p>\n";
}

// show full messages
echo "<p>\n";
$fnt1s = '<font color="#B02020">';  // font 1 start
$fnt1e = "</font>";                 // font 1 end
$fnt2s = '<font color="#303030">';  // font 2 start
$fnt2e = "</font>";                 // font 2 end

mysql_data_seek($result, 0);
while($row = mysql_fetch_object($result)) {

  echo "<a name=\"$row->msgID\" id=\"$row->msgID\"></a>\n";
  echo "<hr /><table>\n";
  echo "<tr><td>$fnt1s Subject:$fnt1e</td>",
    "<td><b>", $fnt2s, htmlentities($row->subject), 
    $fnt2e, "</td></b>\n";
  echo "<tr><td>$fnt1s Author:$fnt1e</td>",
    "<td>", $fnt2s, htmlentities($row->username), 
    $fnt2e, "</td>\n";
  echo "<tr><td>$fnt1s Date:$fnt1e</td>",
    "<td>", "$fnt2s$row->timest$fnt2e</td>\n";
  echo "<tr><td>$fnt1s Forum:$fnt1e</td>",
    "<td>", $fnt2s, htmlentities($row->forumName), 
    $fnt2e, "</td>\n";
  echo "</table>\n";

  $msg = nl2br(htmlentities($row->msgText));
  $msg = str_replace("  ", "&nbsp;&nbsp;", $msg);
  echo "<p>$msg</p>\n";

  // show link to reply to this message
  $query = "msgID=$row->msgID" . $sid2;
  echo "<p>", 
    build_href("forumwrite.php", $query, "Reply to this message"), 
    ".<p>\n";

}

echo "<p><hr />\n";

// show link to group list
echo "<p>", build_href("forumlist.php", SID, "List all forums"), ".\n";

// show link to logout 
echo "<br />", build_href("forumlogout.php", "", "Logout"), ".</p>\n";

// show copyright message for all examples
show_copyright(); 

?>

</body></html>
