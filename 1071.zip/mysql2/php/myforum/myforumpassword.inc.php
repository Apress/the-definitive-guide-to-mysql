<?php    // file myforum/myforumpassword.inc.php   -*- C++ -*- 

// in order to increase the security of this project,
// move myforumpassword.inc.php to another directory
// which is protected against general download by .htaccess
// and change the include line in myforumconnect.inc.php
// accordingly

$mysqluser = "root";           // username
$mysqlpasswd = "";             // password
$mysqlhost = "localhost";      // name of computer MySQL is running
$mysqldbname = "myforum";      // name of database

?>
