<?php // file myforum/forumwrite.php     -*- C++ -*- 

// write a message for the myforum database

// include some standard functions
include("myforumconnect.inc.php");

// url parameters:    forumID, msgID (optional)
// form parameters:   formForumID, formMsgID, formText, formSubject, formSubmit
$forumID     = array_item($_REQUEST, 'forumID');
$msgID       = array_item($_REQUEST, 'msgID');
$formSubmit  = array_item($_POST,    'formSubmit');
$formForumID = array_item($_POST,    'formForumID');
$formMsgID   = array_item($_POST,    'formMsgID');
$formText    = array_item($_POST,    'formText');
$formSubject = array_item($_POST,    'formSubject');

// get rid of magic quotes
if(get_magic_quotes_gpc()) {
  $formText    = stripslashes($formText);
  $formSubject = stripslashes($formSubject); }

// declare session variables
session_start();
header("Cache-control: private"); // IE 6 Fix. 
$sesUserID   = array_item($_SESSION, 'sesUserID');
$sesUserName = array_item($_SESSION, 'sesUserName');
if(SID) {
  $sid1 = "?" . SID;
  $sid2 = "&" . SID; }
else {
  $sid1=""; $sid2=""; }

// function to quote text of previous message
// function reply_text($txt, $subject, $author, $date) {
//   return("\n\n-------------\n\nOriginal message:\n\n" .
//          "Subject: $subject\nAuthor: $author\n" .
//          "Date: $date\n\n$txt");
// }

// function to save new message
function insert_new_message($parentID, $forumID, $userID, 
                            $msgSubject, $msgText) {
  if($parentID) {
    $result =
      mysql_query("SELECT * FROM messages WHERE msgID=$parentID"); 
    $row = mysql_fetch_object($result);
    $level = $row->level+1;
    $orderstr = bin2hex($row->orderstr);
    $rootID = $row->rootID;
    if(!$rootID)  // if rootID=0 use msgID as rootID for new message
      $rootID = $row->msgID;
  }
  else {
    $level=0;    // new messages have level=0 and rootID=0
    $rootID=0;
    $parentID=0;
    $orderstr = '';
  }

  // build orderstr (add hex code of current timestamp)
  // maximum level = 31
  if($level<=31) {
    $tmp = dechex(time());
    if(strlen($tmp)<8)
      $tmp = str_repeat(" ", 8-strlen($tmp));
    $orderstr = "0x" . $orderstr . $tmp;
  }
  else{
    $level=31;
    $orderstr = "0x" . $orderstr; }

  mysql_query("INSERT INTO messages (forumID, parentID, rootID, " .
              "userID, subject, msgText, level, orderstr) " .
              "VALUES($forumID, $parentID, $rootID, $userID, " .
              "       '" . addslashes($msgSubject) . "', " .
              "       '" . addslashes($msgText) . "', " .
              "       $level, $orderstr)");
}


// main code starts here ------------------------------

// connect to database
$connID = connect_to_myforum();

// valid form data to save?
if($formSubmit=="OK" and $formSubject 
   and $formText and $formForumID
   and $sesUserID) {

  // test whether formMsgID (if given) is valid
  $invalidMsgID=0;
  if($formMsgID) {
    $result = 
      mysql_query("SELECT msgID FROM messages  " .
                  "WHERE msgID = '$formMsgID' " .
                  "LIMIT 2");
    if(!$result or mysql_num_rows($result)!=1) 
      $invalidMsgID=1;
  }

  // save data
  if(!$invalidMsgID)
    insert_new_message($formMsgID, $formForumID, $sesUserID,
                       trim(stripslashes($formSubject)),
                       trim(stripslashes($formText)));

  // goto forumread.php and show new message there
  header("Location: forumread.php?forumID=$formForumID$sid2");
  exit;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html><head>
  <meta http-equiv="Content-Type" 
        content="text/html; charset=iso-8859-1" />
  <title>PHP Programming, new message (myforum database)</title>
</head><body>
<h2>myforum: New message</h2>

<?php

// only users logged in may compose messages
if(empty($sesUserID)) {
 ?>
  <p><font color="#ff0000">You must <a href="forumlogin.php">login</a>
  to compose a new message.</font></p>
  </body></html>
 <?php
  show_copyright(); 
  exit; }

// data from message input form is available
if($formForumID) {
  $forumID = $formForumID;
  $msgID = $formMsgID; }


// test if msgID is correct
if($msgID) {
  $result = 
    mysql_query("SELECT msgID, msgText, subject, level, rootID, " .
                "  DATE_FORMAT(messages.timest, '%Y/%c/%e %k:%i') AS timest, " .
                "  forumID, username " .
                "FROM messages, users " .
                "WHERE msgID = '$msgID' " .
                "  AND messages.userID = users.userID " .
                "LIMIT 2");
  // msgID was invalid
  if(!$result or mysql_num_rows($result)!=1) {
    echo '<p><font color="#ff0000">ID number of message seems ', 
      "to be invalid.</font> Please choose a forum in the ",
      "<a href=\"forumlist.php$sid1\">forum list</a>.</p>\n";
    show_copyright(); 
    echo "</body></html>\n";
    exit;
  }
  // retrieve data from $result
  $row = mysql_fetch_object($result);
  $forumID = $row->forumID;
  $oldMsg = $row->msgText;
  $oldSubject = $row->subject;
  $oldLevel = $row->level;
  $oldRoot = $row->rootID;
  $oldAuthor = $row->username;
  $oldDate = $row->timest;
}

// test if forumID is correct, get forum name
$result = mysql_query("SELECT forumID, forumName FROM forums " .
                      "WHERE forumID = '$forumID' " .
                      "LIMIT 2");
if(!$result or mysql_num_rows($result)!=1) {
  echo '<p><font color="#ff0000">ID number of forum seems ', 
    "to be invalid.</font> Please choose a forum in the ",
    "<a href=\"forumlist.php\">forum list</a>.</p>\n";
  show_copyright(); 
  echo "</body></html>\n";
  exit;
}
$forumID = mysql_result($result, 0, 0);
$forumName = mysql_result($result, 0, 1);

// show intro text
if($msgID) {
  $fntBlue = '<font color="#0000ff">';
  echo "<p>$fntBlue", "Reply to message <i>", 
    htmlentities($oldSubject), "</i></font></p>\n";
  echo "<p>$fntBlue", "Original message text:</font></p>\n";
  echo "<p>$fntBlue<i>", 
    str_replace("  ", "&nbsp;&nbsp;", nl2br(htmlentities($oldMsg))),
    "</i></font></p>\n";
}
else 
  echo "<p>New message for forum <i>", htmlentities($forumName), "</i></p>\n";

// declare variables for form
$actionscript = "forumwrite.php$sid1";

$newsubject = "";
if($formSubmit)
  $newsubject = $formSubject;
elseif($msgID) {
  $newsubject = "Re: " . $oldSubject;
  if(strlen($newsubject)>78)
    $newsubject = substr($newsubject, 0, 78);
}

$newtext="";
if($formSubmit)
  $newtext = $formText;

// show form
?>
<form method="post" action="<?php echo $actionscript;?>">
<table>
<tr><td>Author:</td>
    <td> <?php echo htmlentities($sesUserName); ?></td>
<tr><td>Subject:</td>
    <td> <input name="formSubject" size="60" maxlength="78" 
          value="<?php echo htmlspecialchars($newsubject); ?>" /></td>
<tr><td>Message:</td>
    <td><textarea name="formText" rows="12" cols="50"><?php
        echo htmlspecialchars($newtext); ?></textarea></td>
<tr><td></td>
    <td><input type="submit" value="OK" name="formSubmit" /></td>
<input type="hidden" name="formForumID" value="<?php echo $forumID;?>" />
<input type="hidden" name="formMsgID" value="<?php echo $msgID;?>" />
</table></form>

<?php


// show link to logout script
echo "<p><a href=\"forumlogout.php";
if(SID) echo "?$SID";
echo "\">Logout</a>.</p>\n";

// show copyright message for all examples
show_copyright(); 

?>

</body></html>
