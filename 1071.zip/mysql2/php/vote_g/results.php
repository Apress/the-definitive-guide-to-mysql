<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<!-- results.php -->
<html><head>
<meta http-equiv="Content-Type" 
      content="text/html; charset=iso-8859-1" />
<title>Umfrageergebnis</title>
</head><body>
<h2>Umfrageergebnis</h2>
<?php

  $mysqlhost="localhost";
  $mysqluser="root";
  $mysqlpasswd="";
  $mysqldbname="test_vote";

  // Verbindung zur Datenbank herstellen
  $link = 
    @mysql_connect($mysqlhost, $mysqluser, $mysqlpasswd);
  if ($link == FALSE) {
    echo "<p><b>Leider kann keine Verbindung zur Datenbank 
          hergestellt werden. Daher k�nnen die Ergebnisse 
          zur Zeit nicht angezeigt werden. Bitte versuchen 
          Sie es sp�ter noch einmal.</b></p></body></html>\n";
    exit();
  }
  mysql_select_db($mysqldbname);  
  
  // falls Formulardaten zur Verf�gung stehen:
  // auswerten + speichern

  function array_item($ar, $key) {
    if(array_key_exists($key, $ar)) return($ar[$key]);
    return('');  }

  $submitbutton = array_item($_POST, 'submitbutton');
  $vote = array_item($_POST, 'vote');
  
  if($submitbutton=="OK") {
    if($vote>=1 && $vote<=6) {
      mysql_query(
        "INSERT INTO votelanguage (choice) VALUES ($vote)");

    } 
    else {
      echo "<p>Keine g�ltige Wahl. Bitte w�hlen Sie  
            noch einmal. Zur�ck zum
            <a href=\"vote.html\">Wahlformular</a></p>.
            </body></html>\n";
      exit();
    }
  }
  
  // Ergebnisse anzeigen
  echo "<p><b>Welches ist Ihre Lieblings-Programmiersprache
        f�r die Entwicklung von MySQL-Anwendungen?</b></p>\n";

  // Anzahl der abgegebenen Stimmen
  $result  = 
    mysql_query("SELECT COUNT(choice) FROM votelanguage");
  $choice_count = mysql_result($result, 0, 0);

  // Prozentzahlen f�r die einzelnen Ergebnisse
  if($choice_count == 0) {
    echo "<p>Es hat noch keiner gew�hlt.</p>\n";
  } 
  else {
    echo "<p>$choice_count Personen haben bisher an dieser
          Umfrage teilgenommen:</p>\n";
    $choicetext = array("", "C/C++", "Java", "Perl", "PHP", 
                        "ASP[.NET] / C# / VB[.NET] / VBA", 
                        "Andere");
    print("<p><table>\n");
    for($i=1; $i<=6; $i++) {
      $result  = mysql_query(
        "SELECT COUNT(choice) FROM votelanguage " . 
        "WHERE choice = $i");
      $choice[$i] = mysql_result($result, 0, 0); 
      $percent = round($choice[$i]/$choice_count*10000)/100;
      print("<tr><td>$choicetext[$i]:</td>");
      print("<td>$percent %</td></tr>\n");
    }
    print("</table></p>\n");
  }
?>
</body>
</html>
