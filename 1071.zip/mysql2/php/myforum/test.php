<?php // -*- C++ -*- --

include("myforumconnect.inc.php");

session_start();
header("Cache-control: private"); // IE 6 Fix. 

// session_register('count');

show_array($_SESSION);


if(SID) {
  $sid1 = "?" . SID;
  $sid2 = "&" . SID; }
else {
  $sid1=""; $sid2=""; }

echo "<p>sid1=$sid1</p>\n";

$count = array_item($_SESSION, 'mycount');
if($count>=0)
  $count++;
else 
  $count=1;

$_SESSION['mycount']=$count;

?>

You have visited <? echo $count; ?> pages so far!<br /><br />
<?php echo build_href("test.php$sid1", "", "Increment your counter"); ?>
<br />





