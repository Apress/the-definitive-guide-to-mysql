#!/usr/bin/perl -w
# delete-invalid-entries.pl

use strict;
use DBI;

# variables
my($datasource, $user, $passw, $dbh, $sth, $row, $wait_for_return);

# connect to the database
$datasource   = "DBI:mysql:database=mylibraryinno;host=localhost;";
$user  = "root";
$passw = "";
$dbh = DBI->connect($datasource, $user, $passw,
  {'RaiseError' => 1});

# (1a) titles table: search for invalid publIDs

$sth = 
  $dbh->prepare("SELECT title, titleID " .
                "FROM titles LEFT JOIN publishers " .
                "  ON titles.publID=publishers.publID " .
                "WHERE ISNULL(publishers.publID) " .
                "  AND NOT(ISNULL(titles.publID))");
$sth->execute();

# process results, set publID=NULL
while($row = $sth->fetchrow_hashref()) {
  print "set publID=NULL for title: $row->{'title'}\n";
  $dbh->do("UPDATE titles SET publID=NULL " .
           "WHERE titleID=$row->{'titleID'}");
}
$sth->finish();

# (1b) titles table: search for invalid catIDs

$sth = 
  $dbh->prepare("SELECT title, titleID " .
                "FROM titles LEFT JOIN categories " .
                "  ON titles.catID=categories.catID " .
                "WHERE ISNULL(categories.catID) " .
                "  AND NOT(ISNULL(titles.catID))");
$sth->execute();

# process results, set catID=NULL

while($row = $sth->fetchrow_hashref()) {
  print "set catID=NULL for title: $row->{'title'}\n";
  $dbh->do("UPDATE titles SET catID=NULL " .
           "WHERE titleID=$row->{'titleID'}");
}
$sth->finish();


# (2) titles <--> authors: search for invalid authIDs and titleIDs

$sth = 
  $dbh->prepare("SELECT authName, title, rel_title_author.authID, " .
                "       rel_title_author.titleID " .
                "FROM rel_title_author " .
                "LEFT JOIN titles " .
                "       ON rel_title_author.titleID=titles.titleID " .
                "LEFT JOIN authors " .
                "       ON rel_title_author.authID=authors.authID " .
                "WHERE ISNULL(titles.titleID) " .
                "   OR ISNULL(authors.authID)");
$sth->execute();

# process results, delete rel_title_author entries

while($row = $sth->fetchrow_hashref()) {
  print "delete rel_title_author entry:\n"; 
  print "  title  = ", 
    defined($row->{'title'}) ? $row->{'title'} : "NULL", "\n";
  print "  author = ", 
    defined($row->{'authName'}) ? $row->{'authName'} : "NULL", "\n";

  $dbh->do("DELETE FROM rel_title_author " .
           "WHERE authID=$row->{'authID'} " .
           "  AND titleID=$row->{'titleID'}");
}
$sth->finish();

# end
$dbh->disconnect();

print "Please hit Return to end the program!";
$wait_for_return = <STDIN>;
