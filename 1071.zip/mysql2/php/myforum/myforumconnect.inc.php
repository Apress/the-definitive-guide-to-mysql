<?php    //  -*- C++ -*- 
// myforumconnect.inc.php

// connect to MySQL, activate database 'myforum';
// in case of a connection error, show a complete HTML
// document with a short error message

function connect_to_myforum() {

  include("myforumpassword.inc.php");

  $connID = @mysql_pconnect($mysqlhost, $mysqluser, $mysqlpasswd);

  if ($connID) {
    mysql_select_db($mysqldbname);  // default database
    return $connID;
  }
  else {
    echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\">
          <html><head>
          <title>Sorry, no connection ...</title>
          <body><p>Sorry, no connection to database ...</p></body>
          </html>\n"; 
    exit();                        // quit PHP interpreter
  }
}

// test if an array contains a certain entry
// and return its content

function array_item($ar, $key) {
  if(array_key_exists($key, $ar))
    return($ar[$key]); }



// show content of SELECT result; query must be executed
// with mysql_query, NOT with mysql_unbuffered_query!

function show_table($result) 
{
  if(!$result) {
    echo "<p>Error in SQL statement.</p>\n";
    return; 
  }
  
  if(!mysql_num_rows($result)) {
    echo "<p>The query either got no results or was done unbuffered.</p>\n";
    return; 
  }
  
  // set result pointer to beginning of table
  mysql_data_seek($result, 0);

  // get number of rows and columns
  $rows = mysql_num_rows($result);
  $cols = mysql_num_fields($result);
  if($rows>0) {
    echo "<table border=1>";
    // show table heading
    echo "<tr>";
    for($i=0; $i<$cols; $i++) {
      echo "<th>", htmlentities(mysql_field_name($result, $i)), "</th>";
    }
    echo "</tr>";
    
    // show table content
    while($row = mysql_fetch_row($result)) {
      echo "<tr>";
      for($i=0; $i<$cols; $i++) {
        $data = $row[$i];
        if(isset($data)) echo "<td>", htmlentities($data), "</td>";
        else echo "<td><I>NULL</I></td>";
      }
      echo "</tr>\n";
    }
    echo "</table>\n";
  }
}



// build <a href=$url?$query>$name</a>

function build_href($url, $query, $name) {
  if($query)
    return "<a href=\"$url?" . $query . "\">" . htmlentities($name) . "</a>";
  else
    return "<a href=\"$url\">" . htmlentities($name) . "</a>";
}



// execute mysql_query; show SQL string and errors; die if error

function mysql_query_test($sql) {
  echo '<p><font color="#0000ff">SQL: ', htmlentities($sql), 
    "</font></p>\n";
  $result = mysql_query($sql);
  if($result) return($result);
  
  echo '<p><font color="#ff0000">Error: ',
    htmlentities(mysql_error()), "</font></p>\n";
  die();
}



// show content of PHP array, i.e. show_array($_POST)
// this is handy to quickly test what data is in an array

function show_array($x)
{
  if(!is_array($x)) return;
  reset($x);
  echo "<p>content of array</p>\n";
  echo "<p>";
  if($x)
    while($i=each($x))
      echo "<br />", htmlentities($i[0]), " = ", htmlentities($i[1]), "\n";
  echo "</p>\n";
}


// show copyright message

function show_copyright() {
}

?>
