<?php // file myforum/forummessage.php     -*- C++ -*- 

// show one message of a forum
// url parameter: msgID

// include some standard functions
include("myforumconnect.inc.php");

// read URL variables
$msgID = array_item($_REQUEST, 'msgID');

// session management
session_start();
if(empty($_SESSION['sesUserID'])) {
  $_SESSION['sesUserName'] = "anonymous";
}
if(SID) {
  $sid1 = "?" . SID;
  $sid2 = "&" . SID; }
else {
  $sid1=""; $sid2=""; }

// connect to database
$connID = connect_to_myforum();

// main code starts here ------------------------------

// is $msgID empty? --> goto forumlist.php
if(empty($msgID)) {
  header("Location: forumlist.php$sid1");
  exit;
}

?>
<!-- start of html document if no connection error has happened -->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html><head>
  <meta http-equiv="Content-Type" 
        content="text/html; charset=iso-8859-1" />
  <title>PHP Programming, show message (myforum database)</title>
</head><body>
<h2>Show myforum message</h2>

<?php

// test if msgID is valid
$msgID = trim($msgID);
$result = 
  mysql_query("SELECT msgID, rootID, subject, msgText,  " .
              "       username, forumName, messages.forumID, " .
              "       DATE_FORMAT(messages.timest, '%Y/%c/%e %k:%i') AS timest " .
              "FROM messages, users, forums  " .
              "WHERE msgID='$msgID' " .
              "  AND messages.userID = users.userID " .
              "  AND messages.forumID = forums.forumID " .
              "LIMIT 2");
if(!$result or mysql_num_rows($result)!=1) {
  echo '<p><font color="#ff0000">ID number of message seems ', 
    "to be invalid.</font> Please choose a forum in the ",
    "<a href=\"forumlist.php$sid1\">forum list</a>.</p>\n";
  show_copyright(); 
  echo "</body></html>\n";
  exit;
}

// show message
$fnt1s = '<font color="#b02020">';  // font 1 start
$fnt1e = '</font>';                 // font 1 end
$fnt2s = '<font color="#303030">';  // font 2 start
$fnt2e = '</font>';                 // font 2 end
$row = mysql_fetch_object($result);
echo "<table>\n";
echo "<tr><td>$fnt1s Subject:$fnt1e</td><td><b>", $fnt2s, 
  htmlentities($row->subject), $fnt2e, "</td></b>\n";
echo "<tr><td>$fnt1s Author:$fnt1e</td><td>", $fnt2s, 
  htmlentities($row->username), $fnt2e, "</td>\n";
echo "<tr><td>$fnt1s Date:$fnt1e</td><td>",
  "$fnt2s$row->timest$fnt2e</td>\n";
echo "<tr><td>$fnt1s Forum:$fnt1e</td><td>", $fnt2s, 
  htmlentities($row->forumName), $fnt2e, "</td>\n";
echo "</table>\n";

$msg = nl2br(htmlentities($row->msgText));
$msg = str_replace("  ", "&nbsp;&nbsp;", $msg);
echo "<p>$msg\n</p>";

// show link to whole thread
if($row->rootID)
  $query = "rootID=$row->rootID" . $sid2;
else
  $query = "rootID=$row->msgID" . $sid2;
echo "<p>", 
  build_href("forumthread.php", $query, "Show entire thread"), 
  ".\n";

// show link to reply to this message
$query = "forumID=$row->forumID&msgID=$row->msgID" . $sid2;
echo " / ", 
  build_href("forumwrite.php", $query, "Reply to this message"), 
  ".\n";


// show link to write a new message
$query = "forumID=$row->forumID" .$sid2;
echo " / ", 
  build_href("forumwrite.php", $query, "Write a new message"), 
  ".</p>\n";

// show link to group list
echo "<p>", build_href("forumlist.php", SID, "List all forums"), ".\n";

// show link to logout 
echo "<br />", build_href("forumlogout.php", "", "Logout"), ".</p>\n";

// show copyright message for all examples
show_copyright(); 

?>

</body></html>
