<?php  // file mylibrary/find.php     -*- C++ -*- 

// include some standard functions
include("mylibraryconnect.inc.php");

// read form variables ($_POST) and URL variables ($_REQUEST) 
// these lines are not neccessary in PHP <= 4.0
$sqlType          = array_item($_REQUEST, 'sqlType');
$authID           = array_item($_REQUEST, 'authID');
$publID           = array_item($_REQUEST, 'publID');
$search           = array_item($_REQUEST, 'search');
$page             = array_item($_REQUEST, 'page');
$formSearch       = array_item($_POST,    'formSearch');
$formSubmitTitle  = array_item($_POST,    'formSubmitTitle');
$formSubmitAuthor = array_item($_POST,    'formSubmitAuthor');

// remove urlencoding
$search = urldecode($search);

// remove /
if(get_magic_quotes_gpc()) {
  $search = stripslashes($search);
  $formSearch = stripslashes($formSearch); }


// ------------------------------------- functions -------------

// moves first word of string to its end
// i.e. "Kennedy John F." --> "John F. Kennedy"
// see more comments in input.php

function last_name_last($x) {
  $x = trim($x);
  // return unchanged if no blanks
  if(!$pos = strpos($x, " ")) return($x);
  // return swapped parts
  return(trim(substr($x, $pos+1) . " " . substr($x, 0, $pos)));
}

// connect to database
$connID = connect_to_mylibrary();

?>

<!-- start of html document if no connection error has happened -->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html><head>
<meta http-equiv="Content-Type" 
      content="text/html; charset=iso-8859-1" />
<title>PHP Programming, find titles (mylibrary database)</title>
</head><body>
<h2>Search for titles in the mylibrary database</h2>

<?php

// -------- main code starts here ----------------------------------

// show form
if(empty($sqlType) and empty($formSearch)) {

?>

<form method="post" action="find.php">
<p>Please specify the first letters of a book title or 
   of an authors last name.</p>

<p>Search for:
<input name="formSearch" size="20" maxlength="20" /></p>
<p>
<input type="submit" value="Search for title" 
       name="formSubmitTitle" />
<input type="submit" value="Search for author" 
       name="formSubmitAuthor" /></p>
</form>

<?php

   } // end if show form


// declare variables to build sql statement

// nr. of titles shown per page
$pagesize = 5;

// validate page variable
if($page>100)
  $page = 100;
elseif($page<1)
  $page = 1;
elseif(!is_numeric($page))
  unset($page);

// variables to build / save sql command
$sql = "";
$sqlcreate = "CREATE TEMPORARY TABLE tmpTitleIDs TYPE=HEAP ";
if(isset($page))
  $sqllimit = "LIMIT " . (($page-1) * $pagesize) . "," . ($pagesize + 1);
else
  $sqllimit = "LIMIT " . ($pagesize + 1);

// build sql statement from form data
if($formSearch!="") {
  // remove < > " % _ * \ from $formSearch
  $search = trim(stripslashes($formSearch));
  $remove = "<>\"_%*\\";
  for($i=0; $i<strlen($remove); $i++)
    $search = str_replace(substr($remove, $i, 1), "", $search);
  
  if($search=="") 
    unset($search);
  else {
    // search for authors
    if($formSubmitAuthor) {
      echo "<p>Search for authors whose lastnames begin with <i>",
        htmlentities($search), "</i>:</p>\n";
      $sqlType = "author";
      $sql = 
        "SELECT authName, authID FROM authors " . 
        "WHERE authName LIKE '" . addslashes($search) . "%' " .
        "ORDER BY authName " . $sqllimit;
    }
    // search for titles
    else {
      echo "<p>Search for titles beginning with <i>",
        htmlentities($search), "</i>:</p>\n";
      $sqlType = "title";
      $sql = $sqlcreate .
        "SELECT titleID FROM titles " .
        "WHERE title LIKE '" . addslashes($search) . "%' " .
        "ORDER BY title " . $sqllimit;
    }
  }
}

// build sql statement from url variables
elseif($sqlType=="title") {
  // authID is given: query for titles of this author
  if($authID) {
    $result = 
      mysql_query("SELECT authName FROM authors WHERE authID='$authID' LIMIT 2");
    if(mysql_num_rows($result)!=1)
      echo "<p>Sorry, ID number for author seems to be invalid.</p>\n";
    else {
      echo "<p>Titles written by <i>", 
        htmlentities(last_name_last(mysql_result($result, 0, 0))), 
        "</i>:\n";
      $sql = $sqlcreate . 
        "SELECT titles.titleID " .
        "FROM titles, rel_title_author " .
        "WHERE rel_title_author.authID = '$authID' " .
        "  AND titles.titleID = rel_title_author.titleID " . 
        "ORDER BY title " . $sqllimit;
    }
    mysql_free_result($result);
  }

  // publID is given: query for titles published by this publisher
  elseif($publID) {
    $result = 
      mysql_query("SELECT publName FROM publishers WHERE publID='$publID' LIMIT 2");
    if(mysql_num_rows($result)!=1)
      echo "<p>Sorry, ID number for publisher seems to be invalid.</p>\n";
    else {
      echo "<p>Titles published by <i>", 
        mysql_result($result, 0, 0), "</i>:</p>\n";

      $sql = $sqlcreate . 
        "SELECT titleID " .
        "FROM titles " . 
        "WHERE publID = '$publID' " .
        "ORDER BY title " . $sqllimit;
    }
    mysql_free_result($result);
  } 

  // search string is given: query for titles beginning with these letters
  elseif($search) {
    echo "<p>Titles beginning with <i>",
      htmlentities($search), "</i>:\n";
    $sql = $sqlcreate .
      "SELECT titleID FROM titles " .
      "WHERE title LIKE '" . addslashes($search) . "%' " .
      "ORDER BY title " . $sqllimit;
  }
 
  if($page>1)
    echo "Page $page</p>\n";
  else
    echo "</p>\n";
}

// show search results
$titlecount=0;
if(!empty($sql)) {
  if($sqlType=="author") {

    // show authors
    $result = mysql_query($sql);
    if(!$result or !mysql_num_rows($result))
      echo "<p>No results.\n";
    else {
      echo "<hr /><ul>\n";
      while($row = mysql_fetch_object($result)) {
        echo "<li>", 
          build_href("find.php", 
                     "sqlType=title&authID=$row->authID", 
                     last_name_last($row->authName)), 
          "</li>\n";
      }
      echo "</ul>\n";
    }  
  }

  // show titles
  elseif($sqlType=="title") {
    // just in case it is still here: drop tmpTitleIDs
    mysql_query("DROP TABLE IF EXISTS tmpTitleIDs");
    // create new table with title IDs
    mysql_query($sql);
    if(!mysql_affected_rows()) {
      echo "<p>No results.</p>\n";
    }
    else {
      // querys for complete title data
      $result1 = mysql_query
        ("SELECT titles.titleID AS titleID, " .
         "       titles.title AS title, " .
         "       titles.subtitle AS subtitle, " .
         "       titles.edition AS edition, " .
         "       titles.year, " .
         "       titles.isbn, " .
         "       titles.comment, " .
         "       publishers.publName AS publisher, " .
         "       publishers.publID, " .
         "       categories.catName AS category, " .
         "       languages.langName AS language " .
         "FROM titles JOIN tmpTitleIDs" .
         "     LEFT JOIN categories ON titles.catID = categories.catID " .
         "     LEFT JOIN languages ON titles.langID = languages.langID " .
         "     LEFT JOIN publishers ON titles.publID = publishers.publID " .
         "WHERE titles.titleID = tmpTitleIDs.titleID");

      // query for authors
      $result2 = mysql_query
        ("SELECT tmpTitleIDs.titleID, rel_title_author.authID, " .
         "       authName AS author " .
         "FROM authors, rel_title_author, tmpTitleIDs " .
         "WHERE authors.authID = rel_title_author.authID " .
         "  AND rel_title_author.titleID = tmpTitleIDs.titleID " .
         "ORDER BY rel_title_author.authNr, authName");

      // copy authors into array
      while($row = mysql_fetch_object($result2)) {
        // separate authors by a comma
        if(isset($authors[$row->titleID])) 
          $authors[$row->titleID] .= ", ";
        else
          $authors[$row->titleID] = "";
        // add author to author's list; because of ORDER BY clause
        // in the SQL statement the authors are ordered correctly
        $tmp = build_href("find.php", 
                          "sqlType=title&authID=$row->authID", 
                          last_name_last($row->author));
        $authors[$row->titleID] .= $tmp;
      }

      // show title list
      echo "<hr /><ul>\n";
      $titlecount=0;
      while($row = mysql_fetch_object($result1)) {
        $titlecount++;
        if($titlecount<=$pagesize) {
          if($row->publisher)
            $publref = build_href("find.php", 
                                  "sqlType=title&publID=$row->publID", 
                                  $row->publisher);
          // title
          echo "<p><li>", $authors[$row->titleID], ": ",
            "<b>", htmlentities($row->title), "</b>",
            $row->subtitle ? ", " . htmlentities($row->subtitle) . " " : "",
            $row->publisher || $row->year ? "<br />" : "", 
            $row->publisher ? $publref : "",
            $row->year ? ", " . htmlentities($row->year) . " " : "",
            $row->edition ? "<br />Edition: " . htmlentities($row->edition) ." " : "",
            $row->isbn ? "<br />ISBN: " . htmlentities($row->isbn) . " " : "",
            $row->language ? "<br />Language: <i>" . htmlentities($row->language) . "</i> " : "",
            $row->category ? "<br />Category: <i>" . htmlentities($row->category) . "</i> " : "",
            $row->comment ? "<br />Comment: <i>" . htmlentities($row->comment) . "</i> " : "",
            "</li></p>\n";
        }
      }
      echo "</ul>\n";
    
    } // else block for if(!mysql_affected_rows())
    // drop temporary database
    mysql_query("DROP TABLE IF EXISTS tmpTitleIDs");

    // show links to other pages
    echo "<hr />\n";
    if((isset($page) and $page>1) or $titlecount>$pagesize) {
      $query = "sqlType=title";
      $query .= isset($authID) ? "&authID=$authID" : "";
      $query .= isset($publID) ? "&publID=$publID" : "";
      $query .= isset($search) ? "&search=" . urlencode($search) : "";
      echo "<p>More results: ";
      // links to previous pages
      if(isset($page) and $page>1) {
        echo build_href("find.php", 
                        $query . "&page=" . ($page-1), 
                        "Previous page");
        echo " / Page ";
        for($i=1; $i<$page; $i++) {
          if($i>1) echo " ";
          echo " ", 
            build_href("find.php", $query . "&page=" . $i, $i);
        }
      }
      // current page
      if($page>1) 
        echo " ";
      else
        echo "Page ";
      echo "<b>($page)</b> ";
      if($titlecount>$pagesize) {
        if(isset($page)) 
          echo " ";
        else
          $page=1;
        echo build_href("find.php", $query . "&page=" . ($page+1), ($page+1));
        echo " / ";
        echo build_href("find.php", 
                        $query . "&page=" . ($page+1), 
                        "Next page");

      }
      echo "</p>\n";
    }
  }
}

// link back to search form

if($sqlType)
  echo "<p><a href=\"find.php\">Back to search form.</a></p>\n";

show_copyright(); ?>

</body></html>


