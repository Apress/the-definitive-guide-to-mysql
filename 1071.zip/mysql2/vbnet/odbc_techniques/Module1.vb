Option Strict On
Imports System.Data
Imports Microsoft.Data.Odbc

Module Module1
  Dim odbcconn As OdbcConnection

  Sub Main()
    odbcconn = New OdbcConnection( _
      "Driver={MySQL ODBC 3.51 Driver};Server=localhost;" + _
      "Database=innotest;UID=root;PWD=saturn;Options=3")
    odbcconn.Open()

    test()

    odbcconn.Close()
    Console.WriteLine("Return dr�cken")
    Console.ReadLine()
  End Sub

  ' sample for OdbcDataReader
  Sub test()
    Dim tr As OdbcTransaction
    tr = odbcconn.BeginTransaction()
    Dim com As New OdbcCommand("UPDATE table1 SET colB=colB+3 WHERE colA=1", odbcconn, tr)
    com.ExecuteNonQuery()
    Stop
    tr.Commit()
  End Sub
End Module


