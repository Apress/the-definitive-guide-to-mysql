Dieses Beispiel geht davon aus, dass die Datenbank test_images mit der Tabelle images existiert. 

This example assumes that the database test_images with the table images exists.

CREATE DATABASE test_images;

USE test_images;

CREATE TABLE images (
  id    BIGINT NOT NULL AUTO_INCREMENT,
  name  VARCHAR(100) NOT NULL,
  type  VARCHAR(100) NOT NULL,
  image MEDIUMBLOB NOT NULL,
  ts    TIMESTAMP(14) NOT NULL,
  PRIMARY KEY  (id));
