using System;
using ByteFX.Data.MySQLClient;

namespace odbc_connect {
  class mainclass         {
    [STAThread]
    static void Main(string[] args) {
      ByteFXtest tst = new ByteFXtest();
      tst.ReadPublishersDataset();
      Console.WriteLine("Return dr�cken");
      Console.ReadLine();
    }
  }

  class ByteFXtest {
    MySQLConnection myconn;

    public ByteFXtest() {     // use constructor to connect
      myconn = new MySQLConnection(
        "Data Source=localhost;Initial Catalog=mylibraryodbc;" + 
        "User ID=root;Password=saturn;Use Compression=true");
      myconn.Open();
    }

    public void ReadPublishersDataset() {
      MySQLCommand com = new MySQLCommand( 
        "SELECT publID, publName FROM publishers ORDER BY publName", myconn);
      MySQLDataReader dr = com.ExecuteReader();
      while(dr.Read()) {
        Console.WriteLine("id: {0} name: {1}", dr["publID"], dr["publName"]);
      }
      dr.Close();
    }
  }
}
