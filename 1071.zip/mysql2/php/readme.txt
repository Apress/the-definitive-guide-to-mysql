Diese Beispiele geh�ren zum Buch

  Michael Kofler: MySQL, 2. Auflage
  deutsche Ausgabe: Addison-Wesley Germany

Die Beispielprogramme setzen PHP 4.1 voraus. Sie m�ssen die Passwort-Zeichenketten �ndern, damit die Programme laufen. 

vote_e		Englische Version des Umfrage-Einf�hrungsbeispiels (Kapitel 3)
vote_d		Deutsche Version des Umfrage-Einf�hrungsbeispiels (Kapitel 3)
general		Einf�hrungsbeispiel (Kapitel 11)
pictures        Bilder �bertragen/anzeigen  (Kapitel 11)
mylibrary	mylibrary-Beispiele (Kapitel 12)
myforum		myforum-Beispiele  (Kapitel 13)

----------------

Theses samples are part of the book

  Michael Kofler: MySQL
  english edition: apress, 2nd edition

These samples need PHP 4.1. You must change the password strings! For more information, see chapter 3 and 11-13.

vote_e		english version of the vote sample (chapter 3)
vote_d		german version of the vote sample (chapter 3)
pictures        upload/show bitmaps (chapter 11)
general		introduction sample (chapter 11)
mylibrary	mylibrary samples (chapter 12)
myforum		myforum  samples (chapter 13)

---------------

(c) 2001, 2002, 2003 Michael Kofler
