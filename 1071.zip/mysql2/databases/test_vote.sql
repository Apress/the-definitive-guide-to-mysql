-- MySQL dump 9.07
--
-- Host: localhost    Database: test_vote
---------------------------------------------------------
-- Server version	4.0.12-nt-log

--
-- Table structure for table 'votelanguage'
--

CREATE TABLE votelanguage (
  id int(11) NOT NULL default '0',
  choice tinyint(4) NOT NULL default '0',
  ts timestamp(14) NOT NULL,
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table 'votelanguage'
--

INSERT INTO votelanguage VALUES (1,4,20030114154618);
INSERT INTO votelanguage VALUES (2,1,20030114154944);
INSERT INTO votelanguage VALUES (3,4,20030114154950);
INSERT INTO votelanguage VALUES (4,4,20030114154953);
INSERT INTO votelanguage VALUES (5,4,20030114154954);
INSERT INTO votelanguage VALUES (6,2,20030114154958);
INSERT INTO votelanguage VALUES (7,3,20030114155002);
INSERT INTO votelanguage VALUES (8,3,20030114155005);
INSERT INTO votelanguage VALUES (9,5,20030114155012);
INSERT INTO votelanguage VALUES (10,4,20030114155021);
INSERT INTO votelanguage VALUES (11,4,20030114155022);
INSERT INTO votelanguage VALUES (12,4,20030115162526);
INSERT INTO votelanguage VALUES (13,5,20030115163054);

