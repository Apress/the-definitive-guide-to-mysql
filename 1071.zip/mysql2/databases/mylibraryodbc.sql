-- MySQL dump 9.07
--
-- Host: localhost    Database: mylibraryodbc
---------------------------------------------------------
-- Server version	4.0.12-nt-log

--
-- Table structure for table 'authors'
--

CREATE TABLE authors (
  authID int(11) NOT NULL auto_increment,
  authName varchar(60) NOT NULL default '',
  ts timestamp(14) NOT NULL,
  PRIMARY KEY  (authID),
  KEY authName (authName)
) TYPE=MyISAM;

--
-- Dumping data for table 'authors'
--

INSERT INTO authors VALUES (1,'Kofler Michael',20030211142044);
INSERT INTO authors VALUES (2,'Kramer David',20030211142044);
INSERT INTO authors VALUES (3,'Orfali Robert',20030211142044);
INSERT INTO authors VALUES (4,'Harkey Dan',20030211142044);
INSERT INTO authors VALUES (5,'Edwards Jeri',20030211142044);
INSERT INTO authors VALUES (6,'Ratschiller Tobias',20030211142044);
INSERT INTO authors VALUES (7,'Gerken Till',20030211142044);
INSERT INTO authors VALUES (12,'Yarger Randy Jay',20030211142044);
INSERT INTO authors VALUES (13,'Reese Georg',20030211142044);
INSERT INTO authors VALUES (14,'King Tim',20030211142044);
INSERT INTO authors VALUES (15,'Date Chris',20030211142044);
INSERT INTO authors VALUES (16,'Darween Hugh',20030211142044);
INSERT INTO authors VALUES (17,'Krause J�rg',20030211142044);
INSERT INTO authors VALUES (19,'Pohl Peter',20030211142044);
INSERT INTO authors VALUES (20,'Kopka Helmut',20030211142044);
INSERT INTO authors VALUES (21,'Komma Michael',20030211142044);
INSERT INTO authors VALUES (22,'Bitsch Gerhard',20030211142044);
INSERT INTO authors VALUES (23,'Holz Helmut',20030211142044);
INSERT INTO authors VALUES (24,'Schmitt Bernd',20030211142044);
INSERT INTO authors VALUES (25,'Tikart Andreas',20030211142044);
INSERT INTO authors VALUES (26,'Garfinkel Simon',20030211142044);
INSERT INTO authors VALUES (30,'DuBois Paul',20030211142044);
INSERT INTO authors VALUES (37,'Theodor Kallifatides',20030211142044);
INSERT INTO authors VALUES (38,'Goosens Michael',20030211142044);
INSERT INTO authors VALUES (39,'Rahtz Sebastian',20030211142044);
INSERT INTO authors VALUES (47,'Pollack Martin',20030211142044);
INSERT INTO authors VALUES (48,'Gilmore W.J.',20030211142044);
INSERT INTO authors VALUES (51,'Wellington Luke',20030211142044);
INSERT INTO authors VALUES (52,'Thomson Laura',20030211142044);
INSERT INTO authors VALUES (53,'Monjiam Bruce',20030211142044);
INSERT INTO authors VALUES (54,'Gr�be Hans-Gert',20030211142044);
INSERT INTO authors VALUES (55,'Mankell Henning',20030211142044);
INSERT INTO authors VALUES (56,'Kr�ger Guido',20030211142044);
INSERT INTO authors VALUES (57,'Knausg�rd Karl Ove',20030211142044);

--
-- Table structure for table 'categories'
--

CREATE TABLE categories (
  catID int(11) NOT NULL auto_increment,
  catName varchar(60) NOT NULL default '',
  parentCatID int(11) default NULL,
  hierNr int(11) NOT NULL default '0',
  hierIndent tinyint(4) NOT NULL default '0',
  ts timestamp(14) NOT NULL,
  PRIMARY KEY  (catID),
  KEY catName (catName),
  KEY hierNr (hierNr)
) TYPE=MyISAM;

--
-- Dumping data for table 'categories'
--

INSERT INTO categories VALUES (1,'Computer books',11,13,1,20030211142334);
INSERT INTO categories VALUES (2,'Databases',1,16,2,20030211142334);
INSERT INTO categories VALUES (3,'Programming',1,47,2,20030211142334);
INSERT INTO categories VALUES (4,'Relational Databases',2,35,3,20030211142334);
INSERT INTO categories VALUES (5,'Object-oriented databases',2,34,3,20030211142334);
INSERT INTO categories VALUES (6,'PHP',3,55,3,20030211142334);
INSERT INTO categories VALUES (7,'Perl',3,54,3,20030211142334);
INSERT INTO categories VALUES (8,'SQL',2,38,3,20030211142334);
INSERT INTO categories VALUES (9,'Children\'s books',11,1,1,20030211142334);
INSERT INTO categories VALUES (10,'Literature and fiction',11,75,1,20030211142334);
INSERT INTO categories VALUES (11,'All books',NULL,0,0,20030211142334);
INSERT INTO categories VALUES (34,'MySQL',2,33,3,20030211142334);
INSERT INTO categories VALUES (36,'LaTeX, TeX',1,46,2,20030211142334);
INSERT INTO categories VALUES (50,'Java',3,53,3,20030211142334);
INSERT INTO categories VALUES (51,'Visual Basic',3,74,3,20030211142334);
INSERT INTO categories VALUES (52,'VBA',3,73,3,20030211142334);
INSERT INTO categories VALUES (53,'C#',3,51,3,20030211142334);
INSERT INTO categories VALUES (54,'C',3,50,3,20030211142334);
INSERT INTO categories VALUES (55,'C++',3,52,3,20030211142334);

--
-- Table structure for table 'languages'
--

CREATE TABLE languages (
  langID int(11) NOT NULL auto_increment,
  langName varchar(40) NOT NULL default '',
  ts timestamp(14) NOT NULL,
  PRIMARY KEY  (langID)
) TYPE=MyISAM;

--
-- Dumping data for table 'languages'
--

INSERT INTO languages VALUES (1,'english',20030211142354);
INSERT INTO languages VALUES (2,'deutsch',20030211142354);
INSERT INTO languages VALUES (3,'svensk',20030211142354);
INSERT INTO languages VALUES (4,'norsk',20030211142354);

--
-- Table structure for table 'publishers'
--

CREATE TABLE publishers (
  publID int(11) NOT NULL auto_increment,
  publName varchar(60) NOT NULL default '',
  ts timestamp(14) NOT NULL,
  PRIMARY KEY  (publID),
  KEY publName (publName)
) TYPE=MyISAM;

--
-- Dumping data for table 'publishers'
--

INSERT INTO publishers VALUES (2,'apress',20030211142343);
INSERT INTO publishers VALUES (3,'New Riders',20030211142343);
INSERT INTO publishers VALUES (4,'O\'Reilly & Associates',20030211142343);
INSERT INTO publishers VALUES (5,'Hanser',20030211142343);
INSERT INTO publishers VALUES (9,'Bonnier Pocket',20030211142343);
INSERT INTO publishers VALUES (16,'Zsolnay',20030211142343);
INSERT INTO publishers VALUES (1,'Addison-Wesley',20030403154524);
INSERT INTO publishers VALUES (17,'Ordfront f�rlag AB',20030211142343);

--
-- Table structure for table 'rel_title_author'
--

CREATE TABLE rel_title_author (
  titleID int(11) NOT NULL default '0',
  authID int(11) NOT NULL default '0',
  ts timestamp(14) NOT NULL,
  authNr int(11) default NULL,
  PRIMARY KEY  (titleID,authID)
) TYPE=MyISAM;

--
-- Dumping data for table 'rel_title_author'
--

INSERT INTO rel_title_author VALUES (1,1,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (2,1,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (2,2,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (3,3,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (3,4,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (3,5,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (4,6,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (4,7,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (9,12,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (9,13,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (9,14,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (11,15,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (11,16,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (13,1,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (14,1,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (19,19,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (18,19,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (17,17,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (20,19,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (21,20,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (22,1,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (23,1,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (23,21,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (23,22,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (24,1,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (25,23,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (25,24,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (25,25,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (7,30,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (27,26,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (30,1,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (33,1,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (34,1,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (34,2,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (41,17,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (42,37,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (43,38,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (43,39,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (32,57,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (65,56,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (64,55,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (63,55,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (51,47,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (52,48,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (61,53,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (60,30,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (59,52,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (59,51,20030211142403,NULL);
INSERT INTO rel_title_author VALUES (58,1,20030211142403,NULL);

--
-- Table structure for table 'titles'
--

CREATE TABLE titles (
  titleID int(11) NOT NULL auto_increment,
  title varchar(100) NOT NULL default '',
  subtitle varchar(100) default NULL,
  edition tinyint(4) default NULL,
  publID int(11) default NULL,
  catID int(11) default NULL,
  langID int(11) default NULL,
  year int(11) default NULL,
  isbn varchar(20) default NULL,
  comment varchar(255) default NULL,
  ts timestamp(14) NOT NULL,
  authors varchar(255) default NULL,
  PRIMARY KEY  (titleID),
  KEY publIdIndex (publID)
) TYPE=MyISAM;

--
-- Dumping data for table 'titles'
--

INSERT INTO titles VALUES (1,'Linux, 5th ed.',NULL,NULL,1,1,NULL,2000,NULL,NULL,20030212082006,'Kofler Michael');
INSERT INTO titles VALUES (2,'Definitive Guide to Excel VBA',NULL,NULL,2,3,NULL,2000,NULL,NULL,20030212082006,'Kofler Michael; Kramer David');
INSERT INTO titles VALUES (3,'Client/Server Survival Guide',NULL,NULL,1,2,NULL,1997,NULL,NULL,20030212082006,'Edwards Jeri; Harkey Dan; Orfali Robert');
INSERT INTO titles VALUES (4,'Web Application Development with PHP 4.0',NULL,NULL,3,6,NULL,2000,NULL,NULL,20030212082006,'Gerken Till; Ratschiller Tobias');
INSERT INTO titles VALUES (7,'MySQL','',0,3,34,0,2000,'','',20030212082006,'DuBois Paul');
INSERT INTO titles VALUES (9,'MySQL & mSQL',NULL,NULL,4,34,NULL,1999,NULL,NULL,20030212082006,'King Tim; Reese Georg; Yarger Randy Jay');
INSERT INTO titles VALUES (11,'A Guide to the SQL Standard',NULL,NULL,1,8,1,1997,NULL,NULL,20030212082006,'Darween Hugh; Date Chris');
INSERT INTO titles VALUES (13,'Visual Basic',NULL,NULL,1,3,2,NULL,NULL,NULL,20030212082006,'Kofler Michael');
INSERT INTO titles VALUES (14,'Excel 2000 programmieren',NULL,4,1,3,2,NULL,NULL,NULL,20030212082006,'Kofler Michael');
INSERT INTO titles VALUES (20,'Jag saknar dig, jag saknar dig',NULL,NULL,NULL,9,3,NULL,NULL,NULL,20030212082006,'Pohl Peter');
INSERT INTO titles VALUES (21,'LaTeX',NULL,NULL,1,1,2,2000,NULL,NULL,20030212082006,'Kopka Helmut');
INSERT INTO titles VALUES (18,'Nennen wir ihn Anna',NULL,NULL,NULL,9,2,NULL,NULL,NULL,20030212082006,'Pohl Peter');
INSERT INTO titles VALUES (19,'Alltid den d�r Annette',NULL,NULL,NULL,9,3,NULL,NULL,NULL,20030212082006,'Pohl Peter');
INSERT INTO titles VALUES (17,'PHP - Grundlagen und L�sungen','Webserver-Programmierung unter Windows und Linux',NULL,5,NULL,2,NULL,NULL,NULL,20030212082006,'Krause J�rg');
INSERT INTO titles VALUES (22,'Mathematica','Einf�hrung, Anwendung, Referenz',4,1,1,2,1998,'3827312086','CAS',20030212082006,'Kofler Michael');
INSERT INTO titles VALUES (23,'Maple',NULL,4,1,1,2,2001,NULL,'CAS',20030212082006,'Bitsch Gerhard; Kofler Michael; Komma Michael');
INSERT INTO titles VALUES (24,'VBA-Programmierung mit Excel 7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,20030212082006,'Kofler Michael');
INSERT INTO titles VALUES (25,'Linux f�r Internet und Intranet',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,20030212082006,'Holz Helmut; Schmitt Bernd; Tikart Andreas');
INSERT INTO titles VALUES (27,'Practical UNIX & Internet security',NULL,2,4,1,1,1996,'1565921488',NULL,20030212082006,'Garfinkel Simon');
INSERT INTO titles VALUES (30,'Visual Basic Datenbankprogrammierung','Client/Server-Systeme',1,1,2,2,1999,NULL,NULL,20030212082006,'Kofler Michael');
INSERT INTO titles VALUES (32,'Ute av verden',NULL,NULL,NULL,10,4,1998,NULL,NULL,20030212082006,'Knausg�rd Karl Ove');
INSERT INTO titles VALUES (33,'MySQL','Installation, Programmierung, Referenz',1,1,34,2,2001,'3827317622',NULL,20030212082006,'Kofler Michael');
INSERT INTO titles VALUES (34,'MySQL',NULL,1,2,34,1,2001,NULL,'translation',20030212082006,'Kofler Michael; Kramer David');
INSERT INTO titles VALUES (41,'PHP 4',NULL,NULL,NULL,6,2,NULL,'3-446-21546-8',NULL,20030212082006,'Krause J�rg');
INSERT INTO titles VALUES (42,'K�rleken',NULL,NULL,9,10,3,1978,NULL,NULL,20030212082006,'Theodor Kallifatides');
INSERT INTO titles VALUES (43,'Mit LaTeX ins Web','Elektronisches Publizieren mit TeX, HTML und XML',NULL,1,36,2,2000,NULL,NULL,20030212082006,'Goosens Michael; Rahtz Sebastian');
INSERT INTO titles VALUES (61,'PostgreSQL','Einf�hrung und Konzepte',NULL,1,4,2,NULL,NULL,NULL,20030212082006,'Monjiam Bruce');
INSERT INTO titles VALUES (51,'Anklage Vatermord','Der Fall Philipp Halsmann',1,16,10,2,2002,'3552052062',NULL,20030212082006,'Pollack Martin');
INSERT INTO titles VALUES (52,'A Programmer\'s Introduction to PHP 4.0',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,20030212082006,'Gilmore W.J.');
INSERT INTO titles VALUES (60,'MySQL Cookbook','Solutions and Examples for MySQL Database Developers',NULL,4,34,1,2003,NULL,NULL,20030212082006,'DuBois Paul');
INSERT INTO titles VALUES (59,'PHP and MySQL Web Development',NULL,NULL,NULL,6,1,NULL,NULL,NULL,20030212082006,'Thomson Laura; Wellington Luke');
INSERT INTO titles VALUES (58,'Linux, 6th ed',NULL,6,1,1,2,2001,NULL,NULL,20030212082006,'Kofler Michael');
INSERT INTO titles VALUES (63,'Com�dia Infantil',NULL,NULL,17,10,3,NULL,'9173246433',NULL,20030212082006,'Mankell Henning');
INSERT INTO titles VALUES (64,'Hunderna i Riga',NULL,NULL,17,10,3,NULL,'9173246549).',NULL,20030212082006,'Mankell Henning');
INSERT INTO titles VALUES (65,'Java','Handbuch der Java-Programmierung',NULL,1,3,2,2002,NULL,NULL,20030212082006,'Kr�ger Guido');

