<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN"> <!--   -*- C++ -*-  -->

<?php  // file general/intro.php

include("mylibraryconnect.inc.php");
$connID = connect_to_mylibrary();

?>

<html><head>
<meta http-equiv="Content-Type" 
      content="text/html; charset=iso-8859-1" />
<title>PHP Programming, intro sample</title>
</head><body>

<?php 

$result = mysql_query("SELECT COUNT(*) FROM titles");
echo "<p>Table <i>titles</i> contains " . 
  mysql_result($result, 0, 0) . 
  " records.</p>\n";

  show_copyright();  // defined in mylibraryconnect.inc.php

?>

</body></html>
