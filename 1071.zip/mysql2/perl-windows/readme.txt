Diese Beispiele geh�ren zum Buch

  Michael Kofler: MySQL, 2. Auflage
  deutsche Ausgabe: Addison-Wesley Germany, 2003

Bei den Beispielprogrammen handelt es sich um Perl-Scripts. Sie m�ssen die Passwort-Zeichenketten �ndern, damit die Programme laufen. Weitere Informationen finden Sie in Kapitel 14.

----------------

Theses samples are part of the book

  Michael Kofler: MySQL, 2nd edition
  english edition: apress, 2003

To make these samples run, you need Perl. You must also change the password strings! For more information, see chapter 14.

---------------

(c) 2001-2003 Michael Kofler
