This directory contains JSP samples. You need a tomcat installation to test them. The directory mytest must be copied into the webapp directory of tomcat.

page2.jsp only works, if you install the following files:

WEB-INF/c.tld
WEB-INF/sql.tld
WEB-INF/jstl.jar
WEB-INF/standard.jar

These files are part of the JSTL (JSP Standard Tag Library). You will find the JSTL for download here:

http://jakarta.apache.org/taglibs/doc/standard-doc/intro.html

page2.jsp has been testet with JSTL 1.0.2.

Please note that you have to restart tomcat after the installation of the *.tld and *.jar files!


------------------------------------

Dieses Verzeichnis enth�lt JSP-Beispieldateien. Damit Sie die Beispiele testen k�nnen, ben�tigen Sie eine Tomcat-Installation. Das Verzeichnis mytest muss in das webapp-Verzeichnis kopiert werden.

Damit das Beispiel page2.jsp funktioniert, m�ssen die folgenden Dateien hinzugef�gt werden:

WEB-INF/c.tld
WEB-INF/sql.tld
WEB-INF/jstl.jar
WEB-INF/standard.jar

Diese Dateien sind Bestandteil der JSTL (JSP Standard Tag Library). Ein Archiv mit der JSTL finden Sie hier zum Download:

http://jakarta.apache.org/taglibs/doc/standard-doc/intro.html

Die Beispiele wurden mit JSTL 1.0.2 getestet.

Nach der Installation der Dateien muss tomcat neu gestartet werden!
