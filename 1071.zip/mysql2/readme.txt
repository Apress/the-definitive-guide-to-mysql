This directory contains sample databases and code projects for the book:

  MySQL, 2nd edition
  by Michael Kofler
  (c) Apress 2003
