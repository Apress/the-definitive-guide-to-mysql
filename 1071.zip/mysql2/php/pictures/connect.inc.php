<?php    //  -*- C++ -*- 
// pictures/connect.inc.php

// contains various functions which are useful in 
// many PHP/MySQL projects

// connect to MySQL, activate database 'test_pictures';
// in case of a connection error, show a complete HTML
// document with a short error message

function connect_to_picdb() {
  $mysqluser="root";      // username
  $mysqlpasswd="";        // password
  $mysqlhost="localhost"; // name of computer MySQL is running

  $connID = @mysql_connect($mysqlhost, $mysqluser, $mysqlpasswd);

  if ($connID) {
    mysql_select_db("test_images");  // default database
    return $connID;
  }
  else {
    echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\">
          <html><head>
          <title>Sorry, no connection ...</title>
          <body><p>Sorry, no connection to database ...</p></body>
          </html>\n"; 
    exit();                        // quit PHP interpreter
  }
}

// test if an array contains a certain entry
// and return its content

function array_item($ar, $key) {
  if(array_key_exists($key, $ar))
    return($ar[$key]); }


// show content of PHP array

function show_array($x)
{
  if(!is_array($x)) return;
  reset($x);
  echo "<p>content of array</p>\n";
  echo "<p>";
  if($x)
    while($i=each($x))
      echo "<br />", htmlentities($i[0]), " = ", htmlentities($i[1]), "\n";
  echo "</p>\n";
}

// execute mysql_query; show SQL string and errors; die if error

function mysql_query_test($sql) {
  echo "<p><font color=0000ff>SQL: $sql</font></p>\n";
  $result = mysql_query($sql);
  if($result) return($result);
  
  echo "<p><font color=ff0000>Error: ",
    htmlentities(mysql_error()), "</font></p>\n";
  echo "<br><font color=0000ff>SQL: ", htmlentities($sql), "</font>\n";
  die();
}



// show copyright message

function show_copyright() {
}

?>
