#include <iostream>
#include <sqlplus.hh>


using namespace std;


int main(int argc, char *argv[])
{
  Connection conn(use_exceptions);
  try {
    // connect to MySQL server
    conn.connect("mylibrary", "localhost", "root", "uranus");

    // process query
    Query  query = conn.query();
    query << "SELECT publID, publName \
              FROM publishers \
              ORDER BY publName";

    // get results
    Result result = query.store();
    cout << result.size() << " records found:" << endl << endl;
    
    // loop through all records
    Row row;
    Result::iterator it;
    for(it = result.begin(); it != result.end(); it++) {
      row = *it;
      cout << "publId=" << row["publId"] << "  "
	   << "publName=" << row["publName"] << endl; }
    
    // close connection etc.
    result.purge();
    conn.close();

    return 0;

  } // handle connect and query exceptions
    catch(BadQuery er) {
    cerr << "connection or query exception: " << er.error << endl;
    return 1; 
  }
}


/*

#include <vector>
#include <custom.hh>

sql_create_2(publisher,         // name of struct
	     0,                 // no. of fields for comparision
             2,                 // no. of fields total
	     int, publId,       // data publID 
	     string, publName)  // data publName
    // copies result into vector of struct publisher
    vector <publisher> result;
    query.storein(result);  

    // loop through result
    vector <publisher>::iterator it;
    for(it=result.begin(); i!=result.end(); i++) {
      cout << "publID=" << it->publID
	   << "  publName=" << it->publName
	   << endl;
    }
*/
