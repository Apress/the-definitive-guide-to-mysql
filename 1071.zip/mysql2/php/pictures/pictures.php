<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN"> <!-- -*- C++ -*-  -->

<?php {  // pictures/pictures.php

  include("connect.inc.php");
  $connID = connect_to_picdb();

} ?>

<html><head>
<meta http-equiv="Content-Type" 
      content="text/html; charset=iso-8859-1" />
<title>PHP Programming, image upload</title>
</head><body>


<?php {

  // part 1: save uploaded images
  $submitbtn = array_item($_POST, 'submitbtn');
  $descr =     array_item($_POST, 'descr');
  $imgfile =   array_item($_FILES, 'imgfile');
  // is there form data to process?
  if($submitbtn == 'OK' and is_array($imgfile)) {
    $name    = $imgfile['name'];
    $type    = $imgfile['type'];
    $size    = $imgfile['size'];
    $uperr   = array_item($imgfile, 'error'); // PHP >= 4.2.0
    $tmpfile = $imgfile['tmp_name'];
    if(!$descr) $descr = $name;
    switch ($type) {
    case "image/gif":
      $mime = "GIF Image";  break;
    case "image/jpeg":
    case "image/pjpeg":
      $mime = "JPEG Image"; break;
    case "image/png":
    case "image/x-png":
      $mime = "PNG Image";  break;
    default:
      $mime = "unknown";
    }
    if(!$tmpfile or $uperr or $mime == "unknown" or !is_uploaded_file($tmpfile))
      echo "<p>An error occured when processing the form data: 
               Perhaps you forgot to specify an
               image file or the file is too large 
               or the image type is unknown.</p>\n";
    else {
      // read the uploaded file and save it into database
      $file = fopen($tmpfile, "rb");
      $imgdata = fread($file, $size); 
      fclose($file);
      mysql_query(
        "INSERT INTO images (name, type, image) " .
        "VALUES ('" . addslashes($descr) . "', " .
        "        '$mime', " .
        "        '" . addslashes($imgdata) . "')");
      
    }
  }

  // part 2: show images
  echo "<h2>Images recently uploaded ...</h2>\n";
  $result = mysql_query(
    "SELECT id, name, " .
    "DATE_FORMAT(ts, '%Y/%c/%e %k:%i') " .
    "FROM images ORDER BY ts DESC LIMIT 10");
  $rows = mysql_num_rows($result);
  $cols = mysql_num_fields($result);
  if($rows==0)
    echo "<p>No images in database ...</p>\n";
  else {
    echo '<table border="1" cellpadding="5">', "\n<tr>";
    for($i=0; $i < $rows; $i++)  // images
      echo '<th align="center" valign="bottom">',
        "<img src=\"showpic.php?id=" . 
        mysql_result($result, $i, 0) . "\" /></th>";
    echo "</tr>\n<tr>";
    for($i=0; $i < $rows; $i++)  // names/descriptions
      echo "<th>" . htmlentities(mysql_result($result, $i, 1)) . "</th>";
    echo "</tr>\n<tr>";
    for($i=0; $i < $rows; $i++)  // timestamp
      echo "<th>" . mysql_result($result, $i, 2) . "</th>";
    echo "</tr>\n</table>\n"; 

    /*
    // show vertical table
    echo "<table border=1>\n";
    while($row = mysql_fetch_object($result)) {
      echo "<tr>";
      echo "<th>" . htmlentities($row->name) . "</th>";
      echo "<th>$row->ts</th>";
      echo "<th><img src=\"showpic.php?id=$row->id\" /></th>";
      echo "</tr>\n";
    }
    echo "</table>\n"; 
    */
  }

  // part 3: upload form
} ?>

<h2>Upload your picture ...</h2>

<p>Maximum size 100 kByte, only PNG, JPEG and GIF formats supported.</p>

<form method="post" action="pictures.php" enctype="multipart/form-data">
  <input type="hidden" value="10240000" name="MAX_FILE_SIZE" />
  <p>Description: <input name="descr" type="text" /></p>
  <p>Image file:  <input name="imgfile" type="file" /></p>
  <p><input type="submit" value="OK" name="submitbtn" /></p>
</form>

</body></html>
