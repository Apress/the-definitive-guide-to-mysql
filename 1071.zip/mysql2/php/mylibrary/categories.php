<?php  // file mylibrary/categories.php     -*- C++ -*- 

// include some standard functions
include("mylibraryconnect.inc.php");

// read form and URL variables
$submitbutton  = array_item($_POST, 'submitbutton');
$subcategories = array_item($_POST, 'subcategories');
$catID         = array_item($_REQUEST, 'catID');
$deleteID      = array_item($_REQUEST, 'deleteID');

// we need to make sure we have magic quotes
if(!get_magic_quotes_gpc()) 
  $subcategories = addslashes($subcategory);


// -----------------------------------------------  functions

// insert a new category into the categories table

function insert_new_category($catID, $newcatName) {

  // test if newcatName is empty
  if(!$newcatName) return(0);

  // test if newcatName already exists
  $result = 
    mysql_query("SELECT catID FROM categories " . 
                "WHERE parentCatID=$catID " . 
                "  AND catName='$newcatName'");
  if(mysql_num_rows($result)) return(0);
  mysql_free_result($result);

  // LOCK TABLE
  // mysql_query("LOCK TABLE categories WRITE");
  // mysql_query("SET AUTOCOMMIT=0");
  // mysql_query("BEGIN");

  // (1) get data about base record (the category to insert $catName into)
  $result =
    mysql_query("SELECT * FROM categories WHERE catID='$catID'");
  $base=mysql_fetch_object($result);
  mysql_free_result($result);

  // (2a) find category which is alphabetically next after 
  //      newcatName
  $result = 
    mysql_query("SELECT hierNr FROM categories " .
                "WHERE parentCatID='$base->catID' " . 
                "  AND catName>'$newcatName' " .
                "ORDER BY catName LIMIT 1");
  if(mysql_num_rows($result)) {
    $newhierNr = mysql_result($result, 0, 0);
    mysql_free_result($result);
  }

  // (2b) find beginning of categories in higher category level
  else {
    $result = 
      mysql_query("SELECT hierNr FROM categories " .
                  "WHERE hierNr>'$base->hierNr' " . 
                  "  AND hierIndent<='$base->hierIndent' " . 
                  "ORDER BY hierNr LIMIT 1");
    if(mysql_num_rows($result)) {
      $newhierNr = mysql_result($result, 0, 0);
      mysql_free_result($result);
    }

    // (2c) find maximum hierNr
    else {
      $result = 
        mysql_query("SELECT MAX(hiernr) FROM categories");
      $newhierNr = mysql_result($result, 0, 0)+1;
      mysql_free_result($result);
    }
  }

  // (3) increment hierNr for all categories below newcatName
  mysql_query("UPDATE categories SET hierNr=hierNr+1 " .
              "WHERE hiernr>=$newhierNr");

  // (4) insert new category
  mysql_query("INSERT INTO categories " . 
              "  (catName, parentCatID, hierNr, hierIndent) " .
              "VALUES ('$newcatName', $catID, $newhierNr, " .
              ($base->hierIndent+1) . ")");

  // UNLOCK TABLE
  // mysql_query("UNLOCK TABLES");
  // mysql_query("COMMIT");
  // mysql_query("SET AUTOCOMMIT=1");
  return(1);
}



// ------------------------------

// delete a category 

function delete_category($catID) {
  // find subcategories to catID and delete them
  // by calling delete_category recursively
  $result =
    mysql_query("SELECT catID FROM categories " . 
                "WHERE parentCatID='$catID'");
  $rows = mysql_num_rows($result);
  $deletedRows = 0;
  while($row=mysql_fetch_row($result)) {
    $deletedRows += delete_category($row[0]);
  }
  mysql_free_result($result);

  // if any subcategories could not be deleted,
  // don't delete this category as well
  if($deletedRows != $rows) {
    return(0);
  }

  // delete catID
  // don't delete catIDs<=11
  if($catID<=11) {
    echo "<br />You cannot delete categories with catID<=11 in this sample.\n";
    return(0);
  } 

  // do any titles use this category?
  $result = mysql_query("SELECT COUNT(titleID) FROM titles " . 
                        "WHERE catID='$catID'");

  // if category is in use, don't delete it!
  if($nrOfTitles = mysql_result($result, 0, 0)) {
    mysql_free_result($result);
    $result =
      mysql_query("SELECT catName FROM categories " . 
                  "WHERE catID='$catID'");
    $catName = mysql_result($result, 0, 0);
    mysql_free_result($result);
    echo "<br />Category <b>$catName</b> is used in $nrOfTitles ",
      "titles. You cannot delete it and its parents.\n";
    return(0);
  } 

  // delete category
  mysql_query("DELETE FROM categories WHERE catID='$catID'");
  return(1);
}

// ------------------------------------- main code

// connect to database
// show error message if no database connection
$connID = connect_to_mylibrary();

// start of html document if no connection error has happened 
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html><head>
  <meta http-equiv="Content-Type" 
        content="text/html; charset=iso-8859-1" />
  <title>PHP Programming, categories of mylibrary database</title>
</head><body>

<?php 

// test if variable deleteID was set to a valid value;
// if so, delete category (and all subcategories)
if($deleteID) {
  $result = 
    mysql_query("SELECT catID FROM categories " .
                "WHERE catID='$deleteID'");
  if(mysql_num_rows($result)==1)  // make sure no wildcards have been entered
    delete_category($deleteID);
}

// test if variable catID was set to a valid value
$validCatID='';
if($catID) {
  $result = 
    mysql_query("SELECT catID FROM categories WHERE catID='$catID'");
  if(mysql_num_rows($result))
    $validCatID=TRUE;
}

// if url had no valid catID show hierarchical list of all categories
if(!$validCatID) {
  echo "<h2>Choose category</h2>\n";
  echo "<p>Click to insert/delete categories.</p>\n";

  // query for all categories
  $result = mysql_query("SELECT catName, catID, hierIndent " .
                        "FROM categories ORDER BY hierNr");
  
  // show categories as a hierarchical list with links
  // do insert / delete categories
  echo "<p>\n";
  $lastIndent=-1;
  while($row=mysql_fetch_object($result)) {
    // add <ul>'s for next level
    if($row->hierIndent > $lastIndent) 
      echo "<ul>\n";
    // add </ul>'s to get out of level
    if($row->hierIndent < $lastIndent)
      for($i=$row->hierIndent; $i<$lastIndent; $i++)
        echo "</ul>\n";
    $lastIndent = $row->hierIndent;
    // show category name plus insert and delete links
    echo "<li>",
      htmlentities($row->catName), " (",
      build_href("categories.php", "catID=$row->catID", "insert"),
      ", ",
      build_href("categories.php", "deleteID=$row->catID", "delete"),
      ")",
      "</li>\n";
  }
  // close open <ul>'s
  for($i=-1; $i<=$lastIndent; $i++)
    echo "</ul>\n";
  echo "</p>\n";
} 


// if url had valid catID show this category and 
// an input form for new subcategories
else {
  echo "<h2>Insert new categories</h2>\n";

  // if there is form data to process, insert new
  // subcategories into database
  if($subcategories){
    $subcatarray = explode(";", $subcategories);
    $count=0;
    while($i = each($subcatarray)) {
      $newcatname = trim($i[1]);
      $count += insert_new_category($catID, $newcatname);
    }
    if($count)
      echo "<p>$count new categories have been inserted ",
        "into the categories table.</p>\n";
  }

  // build array with current category and all higher categories
  // fetch data for current category
  $result =
    mysql_query("SELECT * FROM categories WHERE catID='$catID'");
  $row = mysql_fetch_object($result);
  $maxIndent = $row->hierIndent;
  $catNames[$maxIndent]     = $row->catName;
  $catIDs[$maxIndent]       = $row->catID;
  $parentCatIDs[$maxIndent] = $row->parentCatID;

  // loop through higher categories
  for($i=$maxIndent-1; $i>=0; $i--) {
    $result =
      mysql_query("SELECT * FROM categories " . 
                  "WHERE catID='" . $parentCatIDs[$i+1] . "'");
    $row = mysql_fetch_object($result);
    $catNames[$i]     = $row->catName;
    $catIDs[$i]       = $row->catID;
    $parentCatIDs[$i] = $row->parentCatID;
  }

  // display higher level categories
  for($i=0; $i<$maxIndent; $i++) {
    echo "<ul><li>", htmlentities($catNames[$i]), "</li>\n";
  }
  // display choosen category bold
  echo "<ul><li><b>", htmlentities($catNames[$maxIndent]), "</b></li>\n";

  // display all subcategories in choosen category  
  // with delete link 
  $result = 
    mysql_query("SELECT catName, catID FROM categories " . 
                "WHERE parentCatID='$catID' ORDER BY catName");
  echo "<ul>\n";
  if(mysql_num_rows($result)) {
    while($row=mysql_fetch_object($result)) {
      echo "<li>", htmlentities($row->catName), " (",
        build_href("categories.php", 
                   "catID=$catID&deleteID=$row->catID", 
                   "delete"),
        ")</li>\n";
    }}
  else {
    echo "(No subcategories yet.)\n";
  }
  echo "</ul>\n";

  // close hierarchical category list
  for($i=0; $i<=$maxIndent; $i++) {
    echo "</ul>\n";
  }

  // display form to insert new categories
  echo '<form method="post" action="categories.php?catID=', 
    $catID, '">', "\n";
  echo "<p>Insert new subcategories to ",
    "<b>$catNames[$maxIndent]</b>. <br />You may add several ",
    "subcategories at once. <br />Use ; to seperate ",
    "your entries.</p>\n";
  echo '<p><input name="subcategories" size="60" maxlength="80" />', "\n";
  echo '<input type="submit" value="OK" name="submitbutton" /></p>', "\n";
  echo "</form>\n";

  // back to categories
  echo "<p>Back to full ",
    build_href("categories.php", "", "categories list") . ".\n";
}

?>
<?php show_copyright(); ?>
</body></html>
