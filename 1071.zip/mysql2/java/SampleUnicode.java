/* SampleUnicode.java */

import java.sql.*;

public class SampleUnicode
{
  public static void main(String[] args)
  {
    try {
      Connection conn1, conn2;
      Statement stmt;
      PreparedStatement pstmt;

      // connect to MySQL
      Class.forName("com.mysql.jdbc.Driver").newInstance();

      // (1) use the charcterset of MySQL Server
      // for Connector/J 3.0.2 and earlier
      // "jdbc:mysql://uranus/exceptions?useUnicode=true&characterEncoding=iso-8859-15"
      conn1 = DriverManager.getConnection(
        "jdbc:mysql://uranus/exceptions", "root", "uranus");

      // process INSERT query with unicode characters
      stmt = conn1.createStatement();
      stmt.executeUpdate("INSERT INTO test_text (a_varchar) VALUES ('')");
      stmt.executeUpdate("INSERT INTO test_text (a_varchar) VALUES ('EURO \u20ac EURO')");
      stmt.executeUpdate("INSERT INTO test_text (a_varchar) VALUES ('Smiley \u263A')");

      /*
      // process prepared INSERT query with unicode characters
      pstmt = conn1.prepareStatement("INSERT INTO test_text (a_varchar) VALUES (?)");
      pstmt.setString(1, "");
      pstmt.executeUpdate();
      pstmt.setString(1, "EURO \u20ac EURO");
      pstmt.executeUpdate();
      pstmt.setString(1, "Smiley \u263A");
      pstmt.executeUpdate();
      */
      conn1.close();


      // (2) use Unicode UTF-8
      conn2 = DriverManager.getConnection(
        "jdbc:mysql://uranus/exceptions?useUnicode=true&characterEncoding=UTF8", "root", "uranus");

      // process INSERT query with unicode characters
      stmt = conn2.createStatement();
      stmt.executeUpdate("INSERT INTO test_text (a_varchar) VALUES ('')");
      stmt.executeUpdate("INSERT INTO test_text (a_varchar) VALUES ('EURO \u20ac EURO')");
      stmt.executeUpdate("INSERT INTO test_text (a_varchar) VALUES ('Smiley \u263A')");

      // process prepared INSERT query with unicode characters
      /*
      pstmt = conn2.prepareStatement("INSERT INTO test_text (a_varchar) VALUES (?)");
      pstmt.setString(1, "");
      pstmt.executeUpdate();
      pstmt.setString(1, "EURO \u20ac EURO");
      pstmt.executeUpdate();
      pstmt.setString(1, "Smiley \u263A");
      pstmt.executeUpdate();
      */ 

      conn2.close();
    }
    catch(Exception e) {
      System.out.println("Error: " + e.toString() );
    }
  }
}

