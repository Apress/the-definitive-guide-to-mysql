Option Strict On
Imports eInfoDesigns.dbProvider.MySqlClient

Module Module1
  Dim myconn As MySQLConnection

  Sub Main()
    myconn = New MySqlConnection( _
      "Data Source=localhost;Database=mylibraryodbc;" + _
      "User ID=root;Password=saturn")
    myconn.Open()

    Console.WriteLine("datareader")
    read_publishers_datareader()

    'Console.WriteLine("dataset")
    'read_publishers_dataset()
    myconn.Close()
    Console.WriteLine("Return dr�cken")
    Console.ReadLine()
  End Sub

  ' sample for OdbcDataReader
  Sub read_publishers_datareader()
    Dim com As MySQLCommand
    Dim dr As MySQLDataReader
    com = New MySQLCommand( _
      "SELECT publID, publName FROM publishers ORDER BY publName", myconn)
    dr = CType(com.ExecuteReader(), MySqlDataReader)
    While dr.Read()
      Console.WriteLine("id: {0} name: {1}", dr!publID, dr!publName)
    End While
    dr.Close()
  End Sub

  ' sample for Dataset
  Sub read_publishers_dataset()
    Dim da As MySqlDataAdapter
    Dim com As MySqlCommand
    Dim ds As DataSet
    Dim row As DataRow
    Dim dt As DataTable

    Try
      ds = New DataSet()
      com = New MySqlCommand("SELECT publID, publName FROM publishers ORDER BY publName", myconn)
      da = New MySqlDataAdapter()
      da.SelectCommand = com
      da.Fill(ds)
      dt = ds.Tables(0)
      For Each row In dt.Rows
        Console.WriteLine("id: {0} name: {1}", row!publID, row!publName)
      Next
      ds.Dispose()
      da.Dispose()
    Catch e As MySQLException
      MsgBox(e.Message)
    End Try
  End Sub

End Module
