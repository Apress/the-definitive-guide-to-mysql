<?php // file myforum/forumlist.php     -*- C++ -*- 

// include some standard functions
include("myforumconnect.inc.php");

// session management
session_start();
if(empty($_SESSION['sesUserID'])) {
  $_SESSION['sesUserName'] = "anonymous";
}
if(SID) {
  $sid1 = "?" . SID;
  $sid2 = "&" . SID; }
else {
  $sid1=""; $sid2=""; }

// connect to database
$connID = connect_to_myforum();

// main code starts here ------------------------------

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN">
<html><head>
  <meta http-equiv="Content-Type" 
        content="text/html; charset=iso-8859-1" />
  <title>PHP Programming, list of discussion groups (myforum database)</title>
</head><body>
<h2>List of <i>myforum</i> discussion forums</h2>

<?php

echo "<p>Username: ", htmlentities($_SESSION['sesUserName']), "</p>\n";

// show list of groups
echo "<p>List of groups:</p>\n";
echo "<ul>\n";
$result = 
  mysql_query("SELECT forumID, forumName, language FROM forums " .
              "ORDER BY forumName, language ");
while($row=mysql_fetch_object($result)) {
  echo "<li>", 
    build_href("forumread.php", 
               "forumID=$row->forumID" . $sid2,
               "$row->forumName ($row->language)"),
    "</li>\n";
}
echo "</ul>\n";

// show link to logout script
echo "<p><a href=\"forumlogout.php$sid1\">Logout</a></p>\n";

// show copyright message for all examples
show_copyright(); 

?>

</body></html>
