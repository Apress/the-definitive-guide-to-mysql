using System;
using CoreLab.MySql;

namespace odbc_connect {
  class mainclass         {
    [STAThread]
    static void Main(string[] args) {
      MySqlDirectTest tst = new MySqlDirectTest();
      tst.ReadPublishersDataset();
      Console.WriteLine("Return dr�cken");
      Console.ReadLine();
    }
  }

  class MySqlDirectTest {
    MySqlConnection myconn;

    public MySqlDirectTest() {     // use constructor to connect
      myconn = new MySqlConnection(
        "Host=localhost;Database=mylibraryodbc;" + 
        "User=root;Password=saturn;Connection Timeout=30");
      myconn.Open();
    }

    public void ReadPublishersDataset() {
      MySqlCommand com = new MySqlCommand( 
        "SELECT publID, publName FROM publishers ORDER BY publName", myconn);
      MySqlDataReader dr = com.ExecuteReader();
      while(dr.Read()) {
        Console.WriteLine("id: {0} name: {1}", dr["publID"], dr["publName"]);
      }
      dr.Close();
    }
  }
}
